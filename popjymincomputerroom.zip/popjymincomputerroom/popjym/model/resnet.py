import equinox as eqx
import jax
from typing import Optional, Type
from equinox.nn import State
from jaxtyping import Array, PRNGKeyArray


def conv3x3(
    in_channels: int,
    out_channels: int,
    stride: int = 1,
    groups: int = 1,
    *,
    key: PRNGKeyArray,
) -> eqx.nn.Conv2d:
    return eqx.nn.Conv2d(
        in_channels,
        out_channels,
        kernel_size=3,
        stride=stride,
        padding=1,
        groups=groups,
        use_bias=False,
        key=key,
    )


def conv1x1(
    in_channels: int, out_channels: int, stride: int = 1, *, key: PRNGKeyArray
) -> eqx.nn.Conv2d:
    return eqx.nn.Conv2d(
        in_channels, out_channels, kernel_size=1, stride=stride, use_bias=False, key=key
    )


class Downsample(eqx.Module):
    conv: eqx.nn.Conv2d
    norm: eqx.nn.GroupNorm

    def __init__(
        self, in_channels: int,
            out_channels: int,
            stride: int,
            groups: int = 32,
            *,
            key: PRNGKeyArray,
    ) -> None:
        self.conv = conv1x1(in_channels, out_channels, stride, key=key)
        self.norm = eqx.nn.GroupNorm(groups, out_channels)

    def __call__(self, x: Array) -> Array:
        x = self.conv(x)
        x = self.norm(x)

        return x


class BasicBlock(eqx.Module):
    conv1: eqx.nn.Conv2d
    gn1: eqx.nn.GroupNorm
    conv2: eqx.nn.Conv2d
    gn2: eqx.nn.GroupNorm
    downsample: Optional[Downsample]

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        stride: int = 1,
        downsample: Optional[Downsample] = None,
        groups: int = 1,
        base_width: int = 64,
        *,
        key: PRNGKeyArray,
    ):
        if groups != 1 or base_width != 64:
            raise ValueError("BasicBlock only supports groups=1 and base_width=64")
        key, conv1_key, conv2_key = jax.random.split(key, 3)
        self.conv1 = conv3x3(in_channels, out_channels, stride, key=conv1_key)
        self.gn1 = eqx.nn.GroupNorm(groups, out_channels)
        self.conv2 = conv3x3(out_channels, out_channels, key=conv2_key)
        self.gn2 = eqx.nn.GroupNorm(groups, out_channels)
        self.downsample = downsample

    def __call__(self, x: Array) -> Array:

        identity = x

        out = self.conv1(x)
        out = self.gn1(out)
        out = jax.nn.relu(out)

        out = self.conv2(out)
        out = self.gn2(out)

        if self.downsample is not None:
            identity = self.downsample(x)

        out += identity
        out = jax.nn.relu(out)

        return out


class Bottleneck(eqx.Module):
    conv1: eqx.nn.Conv2d
    gn1: eqx.nn.GroupNorm
    conv2: eqx.nn.Conv2d
    gn2: eqx.nn.GroupNorm
    conv3: eqx.nn.Conv2d
    gn3: eqx.nn.GroupNorm

    downsample: Optional[Downsample]

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        stride: int = 1,
        downsample: Optional[Downsample] = None,
        groups: int = 1,
        base_width: int = 64,
        *,
        key: PRNGKeyArray,
    ) -> None:
        width = int(out_channels * (base_width / 64.0)) * groups
        conv1_key, conv2_key, conv3_key = jax.random.split(key, 3)
        expansion = 4
        self.conv1 = conv1x1(in_channels, width, key=conv1_key)
        self.gn1 = eqx.nn.GroupNorm(groups, width)
        self.conv2 = conv3x3(width, width, stride, groups, key=conv2_key)
        self.gn2 = eqx.nn.GroupNorm(groups, width)
        self.conv3 = conv1x1(width, out_channels * expansion, key=conv3_key)
        self.gn3 = eqx.nn.GroupNorm(groups, out_channels * expansion)
        self.downsample = downsample

    def __call__(self, x: Array) -> Array:
        identity = x
        x = self.conv1(x)
        x = self.gn1(x)
        x = jax.nn.relu(x)

        x = self.conv2(x)
        x = self.gn2(x)
        x = jax.nn.relu(x)

        x = self.conv3(x)
        x = self.gn3(x)

        if self.downsample is not None:
            identity = self.downsample(identity)

        x += identity
        x = jax.nn.relu(x)

        return x


class ResnetLayer(eqx.Module):
    layers: list[BasicBlock | Bottleneck]

    def __init__(self, layers: list[BasicBlock | Bottleneck]) -> None:
        self.layers = layers

    def __call__(self, x: Array) -> Array:
        for l in self.layers:
            x = l(x)
        return x


class ResNet(eqx.Module):
    in_channels: int = eqx.field(static=True)

    conv1: eqx.nn.Conv2d
    gn1: eqx.nn.GroupNorm
    maxpool: eqx.nn.MaxPool2d

    layer1: ResnetLayer
    layer2: ResnetLayer
    layer3: ResnetLayer
    layer4: ResnetLayer

    avgpool: eqx.nn.AdaptiveAvgPool2d
    fc: eqx.nn.Linear

    def __init__(
        self,
        block: Type[BasicBlock | Bottleneck],
        layers: list[int],
        image_channels: int = 3,
        num_classes: int = 1000,
        groups: int = 1,
        width_per_group: int = 64,
        *,
        key: PRNGKeyArray,
    ) -> None:
        self.in_channels = 64
        key, conv_key = jax.random.split(key)
        self.conv1 = eqx.nn.Conv2d(
            image_channels,
            self.in_channels,
            kernel_size=7,
            stride=2,
            padding=3,
            use_bias=False,
            key=conv_key,
        )
        self.gn1 = eqx.nn.GroupNorm(groups, self.in_channels)
        self.maxpool = eqx.nn.MaxPool2d(kernel_size=3, stride=2, padding=1)
        key, *layer_keys = jax.random.split(key, len(layers) + 1)
        self.layer1 = self._make_layer(
            block,
            out_channels=64,
            num_residual_blocks=layers[0],
            stride=1,
            groups=groups,
            base_width=width_per_group,
            key=layer_keys[0],
        )
        self.layer2 = self._make_layer(
            block,
            out_channels=128,
            num_residual_blocks=layers[1],
            stride=2,
            groups=groups,
            base_width=width_per_group,
            key=layer_keys[1],
        )

        self.layer3 = self._make_layer(
            block,
            out_channels=256,
            num_residual_blocks=layers[2],
            stride=2,
            groups=groups,
            base_width=width_per_group,
            key=layer_keys[2],
        )

        self.layer4 = self._make_layer(
            block,
            out_channels=512,
            num_residual_blocks=layers[3],
            stride=2,
            groups=groups,
            base_width=width_per_group,
            key=layer_keys[3],
        )

        self.avgpool = eqx.nn.AdaptiveAvgPool2d((1, 1))
        key, fc_key = jax.random.split(key)
        self.fc = eqx.nn.Linear(512 * _get_expansion(block), num_classes, key=fc_key)

    def __call__(self, x: Array) -> Array:
        x = self.conv1(x)
        x = self.gn1(x)
        x = jax.nn.relu(x)
        x = self.maxpool(x)

        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)
        x = self.avgpool(x)
        x = x.reshape(-1)
        # x = self.fc(x)
        return x

    def _make_layer(
        self,
        block: Type[BasicBlock | Bottleneck],
        out_channels: int,
        num_residual_blocks: int,
        stride: int,
        groups: int,
        base_width: int,
        *,
        key: PRNGKeyArray,
    ):
        downsample = None
        expansion = _get_expansion(block)
        key, downsample_key = jax.random.split(key)
        if stride != 1 or self.in_channels != out_channels * expansion:
            downsample = Downsample(
                self.in_channels, out_channels * expansion, stride, key=downsample_key
            )
        layers = []
        key, *layer_keys = jax.random.split(key, num_residual_blocks + 1)

        layers.append(
            block(
                self.in_channels,
                out_channels,
                stride,
                downsample,
                groups=groups,
                base_width=base_width,
                key=layer_keys[0],
            )
        )
        self.in_channels = out_channels * expansion
        for i in range(num_residual_blocks - 1):
            layers.append(
                block(
                    self.in_channels,
                    out_channels,
                    groups=groups,
                    base_width=base_width,
                    key=layer_keys[i + 1],
                )
            )
        return ResnetLayer(layers)


def _get_expansion(block_type: Type[Bottleneck | BasicBlock]) -> int:
    if block_type == Bottleneck:
        return 4
    else:
        return 1



def resnet18(
        image_channels: int = 3,
        num_classes: int = 1000,
    *,
        key: PRNGKeyArray,
        make_with_state: bool = False,
        **kwargs: object,
) -> object:
    layers = [2, 2, 2, 2]
    if make_with_state:
        return eqx.nn.make_with_state(ResNet)(
            BasicBlock, layers, image_channels, num_classes, **kwargs, key=key
        )
    else:
        return ResNet(
            BasicBlock, layers, image_channels, num_classes, **kwargs, key=key
        )

def resnet34(
    image_channels: int = 3,
    num_classes: int = 1000,
    *,
    key: PRNGKeyArray,
    make_with_state: bool = False,
    **kwargs,
):
    layers = [3, 4, 6, 3]
    if make_with_state:
        return eqx.nn.make_with_state(ResNet)(
            BasicBlock, layers, image_channels, num_classes, **kwargs, key=key
        )
    else:
        return ResNet(
            BasicBlock, layers, image_channels, num_classes, **kwargs, key=key
        )


def resnet50(
    image_channels: int = 3,
    num_classes: int = 1000,
    *,
    key: PRNGKeyArray,
    make_with_state: bool = False,
    **kwargs,
):
    layers = [3, 4, 6, 3]
    if make_with_state:
        return eqx.nn.make_with_state(ResNet)(
            Bottleneck, layers, image_channels, num_classes, **kwargs, key=key
        )
    else:
        return ResNet(
            Bottleneck, layers, image_channels, num_classes, **kwargs, key=key
        )


def resnet101(
    image_channels: int = 3,
    num_classes: int = 1000,
    *,
    key: PRNGKeyArray,
    make_with_state: bool = False,
    **kwargs,
):
    layers = [3, 4, 23, 3]

    if make_with_state:
        return eqx.nn.make_with_state(ResNet)(
            Bottleneck, layers, image_channels, num_classes, **kwargs, key=key
        )
    else:
        return ResNet(
            Bottleneck, layers, image_channels, num_classes, **kwargs, key=key
        )


def resnet152(
    image_channels: int = 3,
    num_classes: int = 1000,
    *,
    key: PRNGKeyArray,
    make_with_state: bool = False,
    **kwargs,
):
    layers = [3, 8, 36, 3]
    if make_with_state:
        return eqx.nn.make_with_state(ResNet)(
            Bottleneck, layers, image_channels, num_classes, **kwargs, key=key
        )
    else:
        return ResNet(
            Bottleneck, layers, image_channels, num_classes, **kwargs, key=key
        )



# rng = jax.random.PRNGKey(0)
# rng1, rng2 = jax.random.split(rng, 2)
# x = jax.random.normal(rng, (4, 3, 256, 256))
# model, state = resnet18(key=rng2)
# print(model)
# y=eqx.filter_vmap(model)(x)
# print(y.shape)