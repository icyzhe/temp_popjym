import jax
from examples.impala import actor

import popjym
import distrax
import jax.numpy as jnp
import equinox as eqx
import jax.random as jr
from equinox import nn
from jax import lax
from jaxtyping import Array
from typing import Callable, Tuple
from tensorflow_probability.substrates import jax as tfp
from resnet import resnet18
from utils import filter_cond, filter_scan


class NormalDistribution(eqx.Module):
    mean: jnp.ndarray
    stddev: jnp.ndarray

    def __init__(self, mean, stddev):
        self.mean = mean
        self.stddev = stddev

    def sample(self, key):
        samples = jax.random.normal(key, shape=self.mean.shape) * self.stddev + self.mean
        return jnp.clip(jnp.round(samples).astype(int), 1, 5)


class Actor(eqx.Module):
    actor_encoder: eqx.Module
    actor_mean: list

    def __init__(self, key: jr.PRNGKey):
        key1, key2, key3, key4, key5 = jr.split(key, 5)
        self.actor_encoder = resnet18(key=key1, make_with_state=False)
        self.actor_mean = [
            nn.Linear(in_features=512, out_features=256, key=key2),
            jax.nn.tanh,
            nn.Linear(in_features=256, out_features=128, key=key3),
            jax.nn.tanh,
            nn.Linear(in_features=128, out_features=64, key=key4),
            jax.nn.tanh,
            nn.Linear(in_features=64, out_features=2, key=key5),
        ]

        # scaling down the weights of the output layer improves performance
        self.actor_mean = eqx.tree_at(
            where=lambda s: s[-1].weight,
            pytree=self.actor_mean,
            replace_fn=lambda weight: weight * 0.01,
        )

    def __call__(self, x: Array) -> NormalDistribution:

        x = self.actor_encoder(x)

        for operation in self.actor_mean:
            x = operation(x)
        mu, std = jnp.split(x, 2, axis=-1)
        return NormalDistribution(mu, std)

class Critic(eqx.Module):
    critic_encoder: eqx.Module
    critic_value: list

    def __init__(self, key: jr.PRNGKey):
        key1, key2, key3, key4, key5 = jr.split(key, 5)
        self.critic_encoder = resnet18(key=key1, make_with_state=False)
        self.critic_value = [
            nn.Linear(in_features=512, out_features=256, key=key2),
            jax.nn.tanh,
            nn.Linear(in_features=256, out_features=128, key=key3),
            jax.nn.tanh,
            nn.Linear(in_features=128, out_features=64, key=key4),
            jax.nn.tanh,
            nn.Linear(in_features=64, out_features=1, key=key5)
        ]

    def __call__(self, x: Array) -> Array:
        x = self.critic_encoder(x)
        for operation in self.critic_value:
            x = operation(x)

        return x


class Agent(eqx.Module):
    critic: Critic
    actor: Actor

    def __init__(self, key: jr.PRNGKey):
        key1, key2 = jr.split(key, 2)
        self.critic = Critic(key1)
        self.actor = Actor(key2)

    def get_value(self, observation: Array) -> Array:
        """
        get obs and return a number as value, if you use batch_size = 16, return should be shape=(16, 1)
        """
        return self.critic(observation)

    def get_action(self, key: jr.PRNGKey, observation: Array) -> tfp.distributions.Categorical:
        """
        get obs and random key, return a action vector,
        if you use batch_size = 16, return should be shape=(16, 5)
        """
        pi = self.actor(observation)
        action = pi.sample(key)
        return action


class Transition(eqx.Module):
    observation: jax.Array
    action: jax.Array
    value: jax.Array
    reward: jax.Array
    done: jax.Array



"""
Test code for Actor
"""

# key = jr.PRNGKey(0)
# rng, _rng = jr.split(key, 2)
# actor = Actor(key, 5)
# x = jax.random.normal(key, (8, 3, 256, 256))
# y = eqx.filter_vmap(actor)(x)
# print(y.shape)

"""
Test code for Critic
"""

# key = jr.PRNGKey(0)
# rng, _rng = jr.split(key, 2)
# critic = Critic(key)
# x = jax.random.normal(key, (8, 3, 256, 256))
# y = eqx.filter_vmap(critic)(x)
# print(y.shape)

"""
Test code for Agent
"""
#
# key = jr.PRNGKey(0)
# rng, _rng = jr.split(key, 2)
# agent = Agent(key, act_size=5)
# x = jax.random.normal(key, (8, 3, 256, 256))
# y1 = eqx.filter_vmap(agent.get_value)(x)
# key_array = jr.split(rng, x.shape[0])
# y2 = eqx.filter_vmap(agent.get_action)(x)
# print(y2)


def actor_step(
        key: jr.PRNGKey,
        env,
        env_state,
        env_params,
        env_render,
        obs_batch: Array,
        num_envs: int,
        actor: Callable,
        critic: Callable
) -> Tuple:

    rng, _rng = jr.split(key, 2)
    keys_action = jr.split(rng, obs_batch.shape[0])
    action = eqx.filter_vmap(actor)(keys_action, obs_batch)
    value = eqx.filter_vmap(critic)(obs_batch)
    keys_step = jr.split(rng, num_envs)
    obs, next_state, reward, done, info = eqx.filter_vmap(env.step)(keys_step, env_state, action, env_params)
    obs = eqx.filter_vmap(env_render.render)(env_state)
    obs = obs.transpose((0, 3, 1, 2))
    return next_state, Transition(
        observation=obs,
        action=action,
        value=value,
        reward=reward,
        done=done,
    )


def generate_unroll(
        key: jr.PRNGKey,
        env,
        env_state,
        env_params,
        env_render,
        obs_batch: Array,
        num_envs: int,
        actor: Callable,
        critic: Callable,
        unroll_length: int,
) -> Tuple:
    """
    generate steps return a transition that included step info.
    for example, if num_envs = 4, unroll_length = 16,
    you will get transition.observation.shape=(16, 4, 3, 256, 256),
    the same as other element in transition, with shape=(unroll_length, num_envs,...)
    """
    def f(carry, _):
        current_key, state = carry
        current_key, next_key = jr.split(current_key, 2)

        next_state, transition = actor_step(key,
                                            env,
                                            env_state,
                                            env_params,
                                            env_render,
                                            obs_batch,
                                            num_envs,
                                            actor,
                                            critic)

        return (next_key, next_state), transition

    (_, final_state), data = filter_scan(f, (key, env_state), (), length=unroll_length)
    return final_state, data


"""
Run test of the generate_unroll method
"""
key = jr.PRNGKey(10)
key_array = jr.split(key, 4)
env, env_params = popjym.make("CartPole")
env_render = popjym.make_render("CartPoleRender")
obs, env_state = eqx.filter_vmap(env.reset, in_axes=(0, None))(key_array, env_params)
obs = eqx.filter_vmap(env_render.render)(env_state)
obs = obs.transpose((0, 3, 1, 2))
agent = Agent(key)
rng, _rng = jr.split(key, 2)
final_state, data = generate_unroll(_rng,
                                    env,
                                    env_state,
                                    env_params,
                                    env_render,
                                    obs,
                                    obs.shape[0],
                                    agent.get_action,
                                    agent.get_value,
                                    unroll_length=3)
print(data.action)


def compute_loss(
        key: jr.PRNGKey,
        data: Transition,
        agent: eqx.Module,
        num_envs: int,
        config
) -> Tuple:
    """
    compute standard PPO loss on a single trajectory,with clipped surrogate objective
    """
    new_actions = eqx.filter_vmap(agent.get_action)(data.observation)
    baseline = eqx.filter_vmap(agent.get_value)(data.observation)



