from popjym.visualize.visualizer import Visualizer
from jax import lax
import jax.numpy as jnp
import jax
import chex
import functools
from typing import Tuple


class CountRecallRender(Visualizer):
    def __init__(self, canva_size: int = 256, partial_observable: bool = False, canva_color: chex.Array = jnp.array([0.2, 0.2, 0.5])):
        super().__init__()
        self.canva_size = canva_size
        self.partial_observable = partial_observable
        self.large_canva = jnp.zeros((self.canva_size, self.canva_size, 3)) + canva_color
        # self.score = 0
    
    @functools.partial(jax.jit, static_argnums=(0,))
    def render(self, state) -> chex.Array:
        # timestep: int, num_types: int, 
        """
        Renders the game state on a 192x192x3 canvas.
        num_types can be 2 or 4:
        - For num_types=2: [♥, ♠]
        - For num_types=4: [♥, ♠, ♣, ♦]
        """
        large_canva_size = self.canva_size
        large_canva = self.large_canva
        small_canva_size = 192
        light_blue = jnp.array([0.8, 0.8, 0.9])
        small_canva = jnp.zeros((small_canva_size, small_canva_size, 3)) + light_blue
        red = jnp.array([1, 0, 0])
        black = jnp.array([0, 0, 0])
        white = jnp.array([1, 1, 1])
        
        """
        draw value cards and query cards
        """
        value_cards_top_left = (0, 0)
        value_cards_bottom_right = (20, 40)
        
        value_suit_top_left = (0, 0)
        value_suit_bottom_right = (20, 40)
        
        query_cards_top_left = (25, 0)
        query_cards_bottom_right = (45, 40)
        
        query_suit_top_left = (25, 0)
        query_suit_bottom_right = (45, 40)
        
        # Ensure num_types and timestep are scalars
        # `x.astype(int)` or `jnp.array(x, int)`
        # timestep = jnp.zeros(1)
        # num_types = jnp.zeros(1)
        # value_cards = jnp.zeros()
        # timestep = timestep.at[0].set(obs[0])
        # num_types = num_types.at[0].set(obs[1])
        timestep = state.timestep
        num_types = state.num_types
        # reward = int(reward)

        history = state.history.at[state.timestep].set(state.history[state.timestep])
        # def fomdp(small_canva, value_cards, query_cards, history):
        small_canva = self.draw_rectangle(value_cards_top_left, value_cards_bottom_right, white, small_canva)
        small_canva = self.draw_rectangle(query_cards_top_left, query_cards_bottom_right, white, small_canva)
        small_canva = lax.cond(
            state.value_cards[state.timestep] == 0,
            lambda small_canva: self.draw_heart(value_suit_top_left, value_suit_bottom_right, red, small_canva),
            lambda small_canva: lax.cond(
                state.value_cards[state.timestep] == 1,
                lambda small_canva: self.draw_spade(value_suit_top_left, (value_suit_bottom_right[0], value_suit_bottom_right[1] - 6), black, small_canva),
                lambda small_canva: lax.cond(
                    state.value_cards[state.timestep] == 2,
                    lambda small_canva: self.draw_club(value_suit_top_left, (value_suit_bottom_right[0], value_suit_bottom_right[1] - 6), black, small_canva),
                    lambda small_canva: self.draw_diamond(value_suit_top_left, value_suit_bottom_right, red, small_canva),
                    small_canva
                ),
                small_canva
            ),
            small_canva
        )
        small_canva = lax.cond(
            state.query_cards[state.timestep] == 0,
            lambda small_canva: self.draw_heart(query_suit_top_left, query_suit_bottom_right, red, small_canva),
            lambda small_canva: lax.cond(
                state.query_cards[state.timestep] == 1,
                lambda small_canva: self.draw_spade(query_suit_top_left, (query_suit_bottom_right[0], query_suit_bottom_right[1] - 6), black, small_canva),
                lambda small_canva: lax.cond(
                    state.query_cards[state.timestep] == 2,
                    lambda small_canva: self.draw_club(query_suit_top_left, (query_suit_bottom_right[0], query_suit_bottom_right[1] - 6), black, small_canva),
                    lambda small_canva: self.draw_diamond(query_suit_top_left, query_suit_bottom_right, red, small_canva),
                    small_canva
                ),
                small_canva
            ),
            small_canva
        )
        # small_canva = self.draw_spade(value_suit_top_left, value_suit_bottom_right, red, small_canva)
        # small_canva = self.draw_club(query_suit_top_left, query_suit_bottom_right, red, small_canva)
        # use loop to draw history before timestep include timestep, use jax loop        
        """
        draw history
        """
        history_top_left = (0, 80)
        history_bottom_right = (20, 100)
        small_canva = lax.cond(
            self.partial_observable,
            lambda small_canva: small_canva,
            lambda small_canva: lax.fori_loop(0, state.timestep + 1, lambda i, small_canva: lax.cond(
                i < state.timestep,
                lambda small_canva: lax.switch(
                    lax.convert_element_type(state.history[i], int),
                    [
                        lambda small_canva: self.draw_heart(
                            ((i % 10) * 20, (i // 10) * 20 + 40),
                            ((i % 10) * 20 + 14, (i // 10) * 20 + 60),
                            red,
                            small_canva
                        ),
                        lambda small_canva: self.draw_spade(
                            ((i % 10) * 20, (i // 10) * 20 + 40),
                            ((i % 10) * 20 + 10, (i // 10) * 20 + 60),
                            black,
                            small_canva
                        ),
                        lambda small_canva: self.draw_club(
                            ((i % 10) * 20, (i // 10) * 20 + 40),
                            ((i % 10) * 20 + 10, (i // 10) * 20 + 60),
                            black,
                            small_canva
                        ),
                        lambda small_canva: self.draw_diamond(
                            ((i % 10) * 20, (i // 10) * 20 + 40),
                            ((i % 10) * 20 + 14, (i // 10) * 20 + 60),
                            red,
                            small_canva
                        )
                    ],
                    small_canva
                ),
                lambda small_canva: small_canva,
                small_canva
            ), small_canva),
            small_canva
        )

        """
        draw action controller
        30 
        """
        left_triangle_top_left = (large_canva_size//2-50, 228)
        left_triangle_bottom_right = (large_canva_size//2-20, 254)
        right_triangle_top_left = (large_canva_size//2+20, 228)
        right_triangle_bottom_right = (large_canva_size//2+50, 254)
        action_top_left = (large_canva_size//2-10, 230)
        action_bottom_right = (large_canva_size//2+15, 256)
        large_canva = self.draw_triangle(left_triangle_top_left, left_triangle_bottom_right, black, large_canva, 1)
        large_canva = self.draw_triangle(right_triangle_top_left, right_triangle_bottom_right, black, large_canva, 2)
        large_canva = self.draw_number(action_top_left, action_bottom_right, black, large_canva, state.default_action)

        # self.score += reward
        """
        draw score
        """
        score_top_left = (large_canva_size//2-10, 0)
        score_bottom_right = (large_canva_size//2+15, 25)
        large_canva = self.draw_number(score_top_left, score_bottom_right, red, large_canva, state.score)

        """
        draw sub canva in large canva
        """
        large_canva = self.draw_sub_canva(small_canva, large_canva)
        return large_canva
    