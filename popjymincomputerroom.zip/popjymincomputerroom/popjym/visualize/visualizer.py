from jax import lax
from typing import Tuple, Union
import jax
import jax.numpy as jnp
import dm_pix as dm
import chex
import functools


class Visualizer(object):
    def __init__(self, **kwargs):
        self.kwargs = kwargs

    @staticmethod
    @jax.jit
    def draw_rectangle(top_left: Tuple, bottom_right: Tuple, color: chex.Array, canva: chex.Array) -> chex.Array:
        """Draws a rectangle on a blank (256x256x3) canvas."""
        top_x, top_y = top_left
        bottom_x, bottom_y = bottom_right

        x_start = jnp.clip(top_x, 0, canva.shape[0])
        y_start = jnp.clip(top_y, 0, canva.shape[1])
        x_end = jnp.clip(bottom_x, 0, canva.shape[0])
        y_end = jnp.clip(bottom_y, 0, canva.shape[1])

        mask_x = jnp.logical_and(jnp.arange(canva.shape[0]) >= x_start, jnp.arange(canva.shape[0]) < x_end)
        mask_y = jnp.logical_and(jnp.arange(canva.shape[1]) >= y_start, jnp.arange(canva.shape[1]) < y_end)

        mask = jnp.outer(mask_y, mask_x)

        colored_canvas = jnp.where(mask[:, :, None], color, canva)

        return colored_canvas

    @staticmethod
    @jax.jit
    def draw_circle(top_left: Tuple, bottom_right: Tuple, radius: float, color: chex.Array, canva: chex.Array) -> chex.Array:
        """Draws a circle on a blank (256x256x3) canvas."""
        top_x, top_y = top_left
        bottom_x, bottom_y = bottom_right
        center_x = (top_x + bottom_x) // 2
        center_y = (top_y + bottom_y) // 2
        y, x = jnp.ogrid[:canva.shape[1], :canva.shape[0]]
        dist_from_center = jnp.sqrt((x - center_x) ** 2 + (y - center_y) ** 2)

        mask = dist_from_center <= radius
        colored_canvas = jnp.where(mask[:, :, None], color, canva)

        return colored_canvas

    @staticmethod
    @jax.jit
    def draw_triangle(top_left: Tuple, bottom_right: Tuple, color: chex.Array, canva: chex.Array, direction: int):
        """Draws a triangle on a blank (256x256x3) canvas. """
        top_x, top_y = top_left
        bottom_x, bottom_y = bottom_right

        def upward(top_x, top_y, bottom_x, bottom_y):
            return (top_x + bottom_x) // 2, top_y, bottom_x, bottom_y, top_x, bottom_y

        def downward(top_x, top_y, bottom_x, bottom_y):
            return top_x, top_y, bottom_x, top_y, (top_x + bottom_x) // 2, bottom_y

        def leftward(top_x, top_y, bottom_x, bottom_y):
            return top_x, (top_y + bottom_y) // 2, bottom_x, top_y, bottom_x, bottom_y

        def rightward(top_x, top_y, bottom_x, bottom_y):
            return top_x, top_y, bottom_x, (top_y + bottom_y) // 2, top_x, bottom_y

        x1, y1, x2, y2, x3, y3 = lax.cond(
            direction == 1,
            lambda _: upward(top_x, top_y, bottom_x, bottom_y),
            lambda _: lax.cond(
                direction == 2,
                lambda _: downward(top_x, top_y, bottom_x, bottom_y),
                lambda _: lax.cond(
                    direction == 3,
                    lambda _: leftward(top_x, top_y, bottom_x, bottom_y),
                    lambda _: rightward(top_x, top_y, bottom_x, bottom_y),
                    operand=None
                ),
                operand=None
            ),
            operand=None
        )

        def edge_function(x, y, x1, y1, x2, y2):
            return (y - y1) * (x2 - x1) - (x - x1) * (y2 - y1)

        x, y = jnp.meshgrid(jnp.arange(canva.shape[0]), jnp.arange(canva.shape[1]))

        edge1 = edge_function(x, y, x1, y1, x2, y2) >= 0
        edge2 = edge_function(x, y, x2, y2, x3, y3) >= 0
        edge3 = edge_function(x, y, x3, y3, x1, y1) >= 0

        mask = edge1 & edge2 & edge3
        colored_canvas = jnp.where(mask[:, :, None], color, canva)

        return colored_canvas

    @staticmethod
    @jax.jit
    def draw_annulus(top_left: Tuple, bottom_right: Tuple, thickness: int, color: chex.Array, canva: chex.Array) -> chex.Array:
        """"""
        top_x, top_y = top_left
        bottom_x, bottom_y = bottom_right
        cx = (top_x + bottom_x) // 2
        cy = (top_y + bottom_y) // 2
        
        outer_radius = (bottom_x - top_x) // 2
        inner_radius = outer_radius - thickness

        # Create a grid of coordinates
        y, x = jnp.ogrid[:canva.shape[0], :canva.shape[1]]


        # Calculate the distance from the center for each point
        distance_from_center = jnp.sqrt((x - cx)**2 + (y - cy)**2)

        # Create the annulus mask using jax.numpy.where
        annulus_mask = jnp.where((distance_from_center <= outer_radius) & (distance_from_center >= inner_radius), 1, 0)
        
        # Apply the mask to the canvas
        colored_canvas = jnp.where(annulus_mask[:, :, None], color, canva)
        return colored_canvas
    
    @staticmethod
    @jax.jit
    def draw_x(top_left: Tuple, bottom_right: Tuple, color: chex.Array, thickness: int, canva: chex.Array) -> chex.Array:
        """Draws an 'X' inside a rectangle on a blank (256x256x3) canvas."""
        top_x, top_y = top_left
        bottom_x, bottom_y = bottom_right
        y, x = jnp.ogrid[:canva.shape[0], :canva.shape[1]]

        # Create masks for the two lines of the 'X'
        mask1 = jnp.abs((y - top_y) * (bottom_x - top_x) - (x - top_x) * (bottom_y - top_y)) <= thickness * jnp.sqrt((bottom_x - top_x)**2 + (bottom_y - top_y)**2)
        mask2 = jnp.abs((y - bottom_y) * (bottom_x - top_x) - (x - top_x) * (top_y - bottom_y)) <= thickness * jnp.sqrt((bottom_x - top_x)**2 + (bottom_y - top_y)**2)
        mask1 = mask1 & (x >= top_x) & (x <= bottom_x) & (y >= top_y) & (y <= bottom_y)
        mask2 = mask2 & (x >= top_x) & (x <= bottom_x) & (y >= top_y) & (y <= bottom_y)
        # Combine the masks
        mask = mask1 | mask2

        # Apply the color to the canvas where the mask is True
        colored_canvas = jnp.where(mask[:, :, None], color, canva)

        return colored_canvas
    
    @staticmethod
    @jax.jit
    def draw_grid(grid_size: int, thickness: int, color: chex.Array, canva: chex.Array) -> chex.Array:
        """Draws a grid on a 256x256x3 canvas without using for loops."""
        height, width, _ = canva.shape
        
        # Create a mask for the grid lines
        x_indices = jnp.arange(width)
        y_indices = jnp.arange(height)
        
        # Create vertical lines mask
        vertical_lines = (x_indices % grid_size < thickness)
        
        # Create horizontal lines mask
        horizontal_lines = (y_indices % grid_size < thickness)
        
        # Combine masks
        mask = jnp.logical_or(vertical_lines[:, None], horizontal_lines[None, :])
        
        # Apply the mask to the canvas
        colored_canvas = jnp.where(mask[:, :, None], color, canva)
        
        return colored_canvas

    @staticmethod
    @jax.jit
    def draw_sub_canva(sub_canva: chex.Array, canva: chex.Array) -> chex.Array:
        sub_canva_width = sub_canva.shape[0]
        sub_canva_height = sub_canva.shape[1]
        canva_width = canva.shape[0]
        canva_height = canva.shape[1]
        margin_width = (canva_width - sub_canva_width) // 2
        margin_height = (canva_height - sub_canva_height) // 2
        merged_canva = canva.at[margin_width:canva_width - margin_width, margin_height:canva_height - margin_height, :].set(sub_canva)
        return merged_canva

    @staticmethod
    @jax.jit
    def draw_heart(top_left: Tuple, bottom_right: Tuple, color: chex.Array, canva: chex.Array) -> chex.Array:
        """
        Draws a heart shape defined by top_left and bottom_right on the canvas.
        The heart is oriented upward like a standard playing card symbol ♥.
        """
        top_x, top_y = top_left
        bottom_x, bottom_y = bottom_right
        
        # Calculate width and height
        width = bottom_x - top_x
        height = bottom_y - top_y
        size = jnp.minimum(width, height)
        
        # Calculate center and scale
        center_x = (top_x + bottom_x) // 2
        center_y = (top_y + bottom_y) // 2
        scale = size // 2 + 6

        # canvas = jnp.zeros_like(canva)
        y, x = jnp.ogrid[:canva.shape[0], :canva.shape[1]]
        
        # Normalize coordinates to [-2, 2] range within the specified rectangle
        x = (x - center_x) / scale * 2
        y = -((y - center_y) / scale * 2)  # Note the negative sign for upward orientation
        
        # Heart shape equation (modified for upward orientation)
        heart_mask = ((x**2 + y**2 - 1)**3 - (x**2 * y**3)) < 0
        
        # Apply the mask only within the specified rectangle
        within_rect = (x >= (top_x - center_x) / scale * 2) & (x <= (bottom_x - center_x) / scale * 2) & \
                      (y >= (top_y - center_y) / scale * 2) & (y <= (bottom_y - center_y) / scale * 2)
        
        heart_mask = heart_mask & within_rect
        
        colored_canvas = jnp.where(heart_mask[:, :, None], color, canva)
        
        return colored_canvas


    @staticmethod
    @jax.jit
    def draw_spade(top_left: Tuple, bottom_right: Tuple, color: chex.Array, canva:chex.Array) -> chex.Array:
        """
        Draws a spade shape (♠) defined by top_left and bottom_right on the canvas.
        The spade consists of a heart shape rotated 180 degrees and a triangle at the bottom.
        """
        top_x, top_y = top_left
        bottom_x, bottom_y = bottom_right

        # Calculate width and height
        width = bottom_x - top_x
        height = bottom_y - top_y
        size = jnp.minimum(width, height)

        # Calculate center and scale
        center_x = (top_x + bottom_x) / 2
        center_y = (top_y + bottom_y) / 2
        scale = size / 2
        # top_x, top_y = top_left
        # bottom_x, bottom_y = bottom_right

        # Calculate dimensions
        # width = bottom_x - top_x
        # height = bottom_y - top_y

        # Initialize canvas
        # canvas = jnp.zeros((canva.shape[0], canva.shape[1], 3))
        # y, x = jnp.meshgrid(jnp.arange(canva.shape[0]), jnp.arange(canva.shape[1]), indexing='ij')
        y, x = jnp.ogrid[:canva.shape[0], :canva.shape[1]]
        # Split the height: 2/3 for heart, 1/3 for triangle
        heart_height = height * 0.7
        heart_bottom_y = top_y + heart_height

        # Heart part
        # Normalize coordinates for heart shape
        x_heart = (x - (top_x + width/2)) / (width/2) *1.404 # Scale x from -1 to 1
        y_heart = -(y - (top_y + heart_height/2)) / (heart_height/2) *1.404 # Scale y and invert

        # Heart equation
        inverted_heart_mask = ((x_heart**2 + y_heart**2 - 1)**3 - (x_heart**2 * (-y_heart)**3)) < 0

        # Triangle mask
        x1, y1 = center_x, bottom_y - height * 0.8 # Top vertex at the center bottom of the heart
        x2, y2 = center_x + width *0.4, bottom_y + height * 1.8
        x3, y3 = center_x - width *0.4, bottom_y + height * 1.8

        # canvas = jnp.zeros((canva.shape[1], canva.shape[0], 3))

        def edge_function(x, y, x1, y1, x2, y2):
            return (y - y1) * (x2 - x1) - (x - x1) * (y2 - y1)

        # x, y = jnp.meshgrid(jnp.arange(canva.shape[0]), jnp.arange(canva.shape[1]))

        edge1 = edge_function(x, y, x1, y1, x2, y2) >= 0
        edge2 = edge_function(x, y, x2, y2, x3, y3) >= 0
        edge3 = edge_function(x, y, x3, y3, x1, y1) >= 0

        triangle_mask = edge1 & edge2 & edge3
        # Combine masks for spade shape
        spade_mask = inverted_heart_mask | triangle_mask
        boundary_mask = (x >= top_x) & (x <= bottom_x) & (y >= top_y) & (y <= bottom_y)
        spade_mask = (inverted_heart_mask | triangle_mask) & boundary_mask
        
        # Color the canvas
        colored_canvas = jnp.where(spade_mask[:, :, None], color, canva)

        return colored_canvas

    @staticmethod
    @jax.jit
    def draw_club(top_left: Tuple, bottom_right: Tuple, color: chex.Array, canva: chex.Array) -> chex.Array:
        """
        Draws a club shape (♣) within the specified boundary.
        The club consists of three circles and a stem with triangle.
        """
        top_x, top_y = top_left
        bottom_x, bottom_y = bottom_right

        # Calculate dimensions
        width = bottom_x - top_x
        height = bottom_y - top_y

        y, x = jnp.ogrid[:canva.shape[0], :canva.shape[1]]
        # Calculate center and radius
        center_x = (top_x + bottom_x) // 2
        center_y = (top_y + bottom_y) // 2
        radius = jnp.minimum(width, height) // 3.12

        # Create the three circles
        # Top circle
        circle1_x = center_x
        circle1_y = center_y - radius * 0.8
        circle1 = ((x - circle1_x)**2 + (y - circle1_y)**2) <= radius**2

        # Bottom left circle
        circle2_x = center_x - radius * 0.8
        circle2_y = center_y + radius
        circle2 = ((x - circle2_x)**2 + (y - circle2_y)**2) <= radius**2

        # Bottom right circle
        circle3_x = center_x + radius * 0.8
        circle3_y = center_y + radius
        circle3 = ((x - circle3_x)**2 + (y - circle3_y)**2) <= radius**2

        # Create stem
        stem_width = radius * 0.8
        stem_height = height * 0.4
        stem_top_y = center_y + radius
        stem = (jnp.abs(x - center_x) <= stem_width//2) & (y >= stem_top_y) & (y <= bottom_y)

        # Create triangle at the bottom
        triangle_top_y = bottom_y - stem_height * 0.5
        
        def edge_function(px, py, x1, y1, x2, y2):
            return (py - y1) * (x2 - x1) - (px - x1) * (y2 - y1)
        
        # Triangle vertices
        x1, y1 = center_x, triangle_top_y  # Top point
        x2, y2 = center_x - stem_width, bottom_y - 6 # Bottom left
        x3, y3 = center_x + stem_width, bottom_y - 6 # Bottom right

        # Calculate triangle edges
        edge1 = edge_function(x, y, x1, y1, x2, y2) >= 0
        edge2 = edge_function(x, y, x2, y2, x3, y3) >= 0
        edge3 = edge_function(x, y, x3, y3, x1, y1) >= 0
        
        triangle = edge1 & edge2 & edge3

        # Boundary mask
        boundary_mask = (x >= top_x) & (x <= bottom_x) & (y >= top_y) & (y <= bottom_y)

        # Combine all shapes
        club_mask = (circle1 | circle2 | circle3 | stem | triangle) & boundary_mask

        # Color the canvas
        colored_canvas = jnp.where(club_mask[:, :, None], color, canva)

        return colored_canvas


    @staticmethod
    @jax.jit
    def draw_diamond(top_left: Tuple, bottom_right: Tuple, color: chex.Array, canva: chex.Array) -> chex.Array:
        """
        Draws a diamond shape (♦) within the specified boundary.
        The diamond is created using coordinate transformations and masks.
        """
        top_x, top_y = top_left
        bottom_x, bottom_y = bottom_right

        # Calculate dimensions
        width = bottom_x - top_x
        height = bottom_y - top_y

        # Initialize canvas
        # canvas = jnp.zeros((canva.shape[0], canva.shape[1], 3))
        # y, x = jnp.meshgrid(jnp.arange(canva.shape[0]), jnp.arange(canva.shape[1]), indexing='ij')
        y, x = jnp.ogrid[:canva.shape[0], :canva.shape[1]]
        # Calculate center
        center_x = (top_x + bottom_x) // 2
        center_y = (top_y + bottom_y) // 2

        # Scale factors for x and y directions
        scale_x = width // 2
        scale_y = height // 2

        # Normalize coordinates to [-1, 1] range
        x_norm = (x - center_x) / scale_x * 1.48
        y_norm = (y - center_y) / scale_y * 1.48

        # Create diamond mask using normalized coordinates
        diamond_mask = (jnp.abs(x_norm) + jnp.abs(y_norm)) <= 1.0

        # Apply boundary mask
        boundary_mask = (x >= top_x) & (x <= bottom_x) & (y >= top_y) & (y <= bottom_y)
        final_mask = diamond_mask & boundary_mask

        # Color the canvas
        colored_canvas = jnp.where(final_mask[:, :, None], color, canva)

        return colored_canvas

    @staticmethod
    @jax.jit
    def draw_crooked_tail(top_left: Tuple, bottom_right: Tuple, color: chex.Array, thickness: int, canva: chex.Array) -> chex.Array:
        """Draws a quarter circle ring on a blank (256x256x3) canvas."""
        top_x, top_y = top_left
        bottom_x, bottom_y = bottom_right
        center_x = (top_x + bottom_x) // 2
        center_y = (top_y + bottom_y) // 2
        y, x = jnp.ogrid[:canva.shape[0], :canva.shape[1]]
        dist_from_center = jnp.sqrt((x - center_x) ** 2 + (y - center_y) ** 2)
        radius = (bottom_x - top_x) // 2
        # Create masks for the outer and inner circles
        outer_mask = dist_from_center <= radius
        inner_mask = dist_from_center <= (radius - thickness)

        # Combine masks to get the ring
        ring_mask = outer_mask & ~inner_mask

        # Apply the mask to the canvas
        crooked_tail = jnp.where(ring_mask[:, :, None], color, canva)

        quarter_mask = (x >= center_x) & (y <= center_y)
        #  Mask out the three-quarters of the circle to get a quarter circle
        crooked_tail = jnp.where(quarter_mask[:, :, None], crooked_tail, canva)

        return crooked_tail

    @staticmethod
    @jax.jit
    def draw_stick(top_left: Tuple, bottom_right: Tuple, angle: float, thickness: int, color: chex.Array, canva: chex.Array) -> chex.Array:
        """Draws a vertical stick on a blank (256x256x3) canvas."""
        top_x, top_y = top_left
        bottom_x, bottom_y = bottom_right
        bottom_stick_x = (bottom_x + top_x) // 2
        bottom_stick_y = bottom_y

        length = bottom_x - top_x

        # Calculate the top point of the stick
        top_stick_x = bottom_stick_x + length * jnp.sin(angle * jnp.pi)
        top_stick_y = bottom_stick_y - length * jnp.cos(angle * jnp.pi)

        y, x = jnp.ogrid[:canva.shape[0], :canva.shape[1]]

        # Calculate the distance from each point to the line
        dist_to_line = jnp.abs((top_stick_y - bottom_stick_y) * x - (
                top_stick_x - bottom_stick_x) * y + top_stick_x * bottom_stick_y - top_stick_y * bottom_stick_x) / jnp.sqrt(
            (top_stick_y - bottom_stick_y) ** 2 + (top_stick_x - bottom_stick_x) ** 2)

        # Create a mask for the stick
        mask = (dist_to_line <= thickness / 2) & (x >= jnp.minimum(bottom_x, top_x)) & (
                x <= jnp.maximum(bottom_x, top_x)) & (y >= jnp.minimum(bottom_y, top_y)) & (
                       y <= jnp.maximum(bottom_y, top_y))

        # Apply the color to the canvas
        colored_canvas = jnp.where(mask[:, :, None], color, canva)

        return colored_canvas


    @staticmethod
    @jax.jit
    def return_digit_patterns(index: int) -> chex.Array:

        digit_patterns = jnp.array([
            # 0
            [
                [False, True, True, True, False],
                [False, True, False, True, False],
                [False, True, False, True, False],
                [False, True, False, True, False],
                [False, True, True, True, False]
            ],

            # 1
            [
                [False, False, True, False, False],
                [False, True, True, False, False],
                [False, False, True, False, False],
                [False, False, True, False, False],
                [False, True, True, True, False]
            ],

            # 2
            [
                [True, True, True, True, False],
                [False, False, False, True, False],
                [True, True, True, True, False],
                [True, False, False, False, False],
                [True, True, True, True, False]
            ],

            # 3
            [
                [True, True, True, True, False],
                [False, False, False, True, False],
                [True, True, True, True, False],
                [False, False, False, True, False],
                [True, True, True, True, False]
            ],

            # 4
            [
                [True, False, False, True, False],
                [True, False, False, True, False],
                [True, True, True, True, False],
                [False, False, False, True, False],
                [False, False, False, True, False]
            ],

            # 5
            [
                [True, True, True, True, False],
                [True, False, False, False, False],
                [True, True, True, True, False],
                [False, False, False, True, False],
                [True, True, True, True, False]
            ],

            # 6
            [
                [True, True, True, True, False],
                [True, False, False, False, False],
                [True, True, True, True, False],
                [True, False, False, True, False],
                [True, True, True, True, False]
            ],

            # 7
            [
                [True, True, True, True, True],
                [False, False, False, False, True],
                [False, False, False, True, False],
                [False, False, True, False, False],
                [False, True, False, False, False]
            ],

            # 8
            [
                [True, True, True, True, False],
                [True, False, False, True, False],
                [True, True, True, True, False],
                [True, False, False, True, False],
                [True, True, True, True, False]
            ],

            # 9
            [
                [True, True, True, True, False],
                [True, False, False, True, False],
                [True, True, True, True, False],
                [False, False, False, True, False],
                [True, True, True, True, False]
            ],
            
        ])
        return digit_patterns[index]

    @staticmethod
    @jax.jit
    def draw_digit(top_left: Tuple[int, int], bottom_right: Tuple[int, int], color: chex.Array, canva: chex.Array, digit: int) -> chex.Array:
        """
        Draws a specified digit defined by top_left and bottom_right on the canvas.
        The digit is represented by a 5x5 grid of rectangles.
        """
        top_x, top_y = top_left
        bottom_x, bottom_y = bottom_right
        
        # calculate width and height of each rectangle
        width = (bottom_x - top_x) // 5
        height = (bottom_y - top_y) // 5
        
        # get relevant digit
        digit_pattern = Visualizer.return_digit_patterns(digit)
        
        # init canvas
        # canvas = jnp.zeros_like(canva)
        
        # draw rectangles based on digit pattern
        for i in range(5):
            for j in range(5):
                canva = jax.lax.cond(
                    digit_pattern[i, j],
                    lambda c: Visualizer.draw_rectangle((top_x + j * width, top_y + i * height), (top_x + (j + 1) * width, top_y + (i + 1) * height), color, c),
                    lambda c: c,
                    canva
                )
        return canva

    @staticmethod
    @jax.jit
    def draw_number(top_left: Tuple[int, int], bottom_right: Tuple[int, int], color: chex.Array, canva: chex.Array,
                    number: int) -> chex.Array:
        """
        Draws a multi-digit number on the canvas.
        Each digit is drawn with some horizontal offset.
        """
        # Calculate the width for each digit
        digit_width = (bottom_right[0] - top_left[0]) // 5

        def cond_fn(val):
            num_digits, temp_number, flag = val
            return flag == True

        def body_fn(val):
            num_digits, temp_number, flag = val
            temp_number = temp_number // 10
            num_digits += 1
            flag = lax.cond(temp_number > 0, lambda _: True, lambda _: False, operand=None)
            return num_digits, temp_number, flag

        temp_number = number
        num_digits = 0
        flag = True
        out_result = lax.while_loop(cond_fn, body_fn, init_val=(num_digits, temp_number, flag))
        num_digits = out_result[0]
        idx = 0

        def cond_fun(state):
            idx, num_digits, _, _, _, _, _ = state
            return idx < num_digits

        def body_fun(state):
            idx, num_digits, number, top_left, bottom_right, color, canva = state
            digit = number // (10 ** (num_digits - idx - 1)) % 10
            digit_top_left = (top_left[0] + idx * digit_width * 5, top_left[1])  # 添加水平偏移
            digit_bottom_right = (digit_top_left[0] + digit_width * 5, bottom_right[1])
            canva = Visualizer.draw_digit(digit_top_left, digit_bottom_right, color, canva, digit)
            idx += 1
            return idx, num_digits, number, top_left, bottom_right, color, canva

        initial_state = (0, num_digits, number, top_left, bottom_right, color, canva)
        final_state = lax.while_loop(cond_fun, body_fun, initial_state)

        return final_state[-1]

    @staticmethod
    @jax.jit
    def draw_straight_tail(top_left: Tuple[int, int], bottom_right: Tuple[int, int], thickness: int, color: chex.Array,
                           canva: chex.Array) -> chex.Array:
        """Draws a horizontal line on a canvas with specified thickness."""
        top_x, top_y = top_left
        bottom_x, bottom_y = bottom_right
        start_x = top_x
        start_y = (top_y + bottom_y) // 2
        end_x = bottom_x
        end_y = (top_y + bottom_y) // 2

        x_start = jnp.clip(start_x, 0, canva.shape[0])
        x_end = jnp.clip(end_x, 0, canva.shape[0])
        y_start = jnp.clip(start_y - thickness // 2, 0, canva.shape[1])
        y_end = jnp.clip(start_y + thickness // 2, 0, canva.shape[1])

        mask_x = jnp.logical_and(jnp.arange(canva.shape[0]) >= x_start, jnp.arange(canva.shape[0]) < x_end)
        mask_y = jnp.logical_and(jnp.arange(canva.shape[1]) >= y_start, jnp.arange(canva.shape[1]) < y_end)

        mask = jnp.outer(mask_y, mask_x)

        colored_canvas = jnp.where(mask[:, :, None], color, canva)

        return colored_canvas

    @staticmethod
    @jax.jit
    def draw_straight_arrow(top_left: Tuple[int, int], bottom_right: Tuple[int, int],
                            color: chex.Array, velocity: float, canva: chex.Array) -> chex.Array:
        def map_to_thickness(value, minimum):
            value = minimum + value * 2
            return value

        def map_to_head(value, minimum):
            value = minimum + value * 5
            return value

        thickness = map_to_thickness(abs(velocity), 2).astype(int)
        top_x, top_y = top_left
        bottom_x, bottom_y = bottom_right
        mid_y = (top_y + bottom_y) // 2
        head_margin = map_to_head(abs(velocity), 5).astype(int)
        tail_top_left = (top_x + head_margin, top_y)
        tail_bottom_right = (bottom_x, bottom_y)
        canva = Visualizer.draw_straight_tail(tail_top_left, tail_bottom_right, thickness, color, canva)

        def left_velocity(canva):
            head_top_left = (tail_top_left[0] - head_margin, mid_y - head_margin // 2)
            head_bottom_right = (tail_top_left[0], mid_y + head_margin // 2)
            canva = Visualizer.draw_triangle(head_top_left, head_bottom_right, color, canva, direction=3)
            return canva

        def right_velocity(canva):
            head_top_left = (tail_bottom_right[0], mid_y - head_margin // 2)
            head_bottom_right = (tail_bottom_right[0] + head_margin, mid_y + head_margin // 2)
            canva = Visualizer.draw_triangle(head_top_left, head_bottom_right, color, canva, direction=4)
            return canva

        canva = lax.select(velocity > 0, right_velocity(canva), left_velocity(canva))
        return canva

    @staticmethod
    @jax.jit
    def draw_crooked_arrow(top_left: Tuple[int, int], bottom_right: Tuple[int, int],
                           color: chex.Array, angular_velocity: float, canva: chex.Array) -> chex.Array:

        def map_to_thickness(value, minimum):
            value = minimum + value * 2
            return value

        def map_to_head(value, minimum):
            value = minimum + value * 5
            return value

        thickness = map_to_thickness(abs(angular_velocity), 2).astype(int)
        top_x, top_y = top_left
        bottom_x, bottom_y = bottom_right
        canva = Visualizer.draw_crooked_tail(top_left, bottom_right, color, thickness, canva)
        head_margin = map_to_head(abs(angular_velocity), 5).astype(int)
        mid_x = (top_x + bottom_x) // 2
        mid_y = (top_y + bottom_y) // 2

        def right_velocity(canva):
            mid_ring = (bottom_x - thickness // 2, mid_y)
            head_top_left = (mid_ring[0] - head_margin // 2, mid_y)
            head_bottom_right = (mid_ring[0] + head_margin // 2, mid_y + head_margin)
            canva = Visualizer.draw_triangle(head_top_left, head_bottom_right, color, canva, direction=2)
            return canva

        def left_velocity(canva):
            mid_ring = (mid_x, top_y + thickness // 2)
            head_top_left = (mid_x - head_margin, mid_ring[1] - head_margin // 2)
            head_bottom_right = (mid_x, mid_ring[1] + head_margin // 2)
            canva = Visualizer.draw_triangle(head_top_left, head_bottom_right, color, canva, direction=3)
            return canva

        canva = lax.select(angular_velocity > 0, right_velocity(canva), left_velocity(canva))
        return canva

    @staticmethod
    @jax.jit
    def rotate(image: chex.Array, angle: float, center: Tuple[int, int], order: int = 1, mode: str = "nearest", cval: float = 0.0) -> chex.Array:
        c = jnp.cos(-angle)
        s = jnp.sin(-angle)
        matrix = jnp.array([[c, s, 0], [-s, c, 0], [0, 0, 1]])

        # Use the offset to place the rotation at the image center.
        center = jnp.asarray(center)
        image_center = (jnp.asarray(image.shape) - 1.) / 2.
        image_center = image_center.at[:2].set(center)
        offset = image_center - matrix @ image_center

        return dm.affine_transform(image, matrix, offset=offset, order=order, mode=mode,
                                   cval=cval)

    @staticmethod
    @jax.jit
    def draw_bar(top_left: Tuple[int, int], bottom_right: Tuple[int, int], angle: float, thickness: int, color: chex.Array, canva: chex.Array) -> chex.Array:
        """Draws a vertical bar with specified thickness on a blank (256x256x3) canvas."""
        top_x, top_y = top_left
        bottom_x, bottom_y = bottom_right
        x = (top_x + bottom_x) // 2
        x_start = jnp.clip(x - thickness // 2, 0, canva.shape[0])
        x_end = jnp.clip(x + thickness // 2, 0, canva.shape[0])
        y_start = jnp.clip(top_y, 0, canva.shape[1])
        y_end = jnp.clip(bottom_y, 0, canva.shape[1])

        mask_x = jnp.logical_and(jnp.arange(canva.shape[0]) >= x_start, jnp.arange(canva.shape[0]) < x_end)
        mask_y = jnp.logical_and(jnp.arange(canva.shape[1]) >= y_start, jnp.arange(canva.shape[1]) < y_end)

        mask = jnp.outer(mask_y, mask_x)
        colored_canvas = jnp.where(mask[:, :, None], color, canva)
        colored_canvas = Visualizer.rotate(colored_canvas, angle=angle, center=(x, bottom_y))
        return colored_canvas

