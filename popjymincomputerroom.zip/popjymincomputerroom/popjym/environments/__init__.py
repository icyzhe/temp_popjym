from popjym.environments.cartpole import CartPole

from popjym.environments.countrecall import (CountRecallEasy,
                                             CountRecallHard,
                                             CountRecallMedium,
                                             FullyObservableCountRecallEasy,
                                             FullyObservableCountRecallHard,
                                             FullyObservableCountRecallMedium,
                                             )
from popjym.environments.battleship import (BattleShipEasy,
                                            BattleShipMedium,
                                            BattleShipHard,
                                            )
