"""
dqn
"""
import jax
import jax.numpy as jnp
import equinox as eqx
import numpy as np
import popjym
import equinox.nn as nn
import distrax
from typing import Sequence, Tuple, NamedTuple
from jaxtyping import PRNGKeyArray, Array


class QNetwork(eqx.Module):
    action_dim: int
    dense1: nn.Linear
    dense2: nn.Linear
    dense3: nn.Linear
    dense4: nn.Linear
    activation: str = "tanh"

    def __init__(self, key: PRNGKeyArray, action_dim: int):
        self.action_dim = action_dim
        key_array = jax.random.split(key, 4)
        self.dense1 = nn.Linear(in_features=512, out_features=256, key=key_array[0])
        self.dense2 = nn.Linear(in_features=256, out_features=128, key=key_array[1])
        self.dense3 = nn.Linear(in_features=128, out_features=64, key=key_array[2])
        self.dense4 = nn.Linear(in_features=64, out_features=action_dim, key=key_array[3])
        if self.activation == "relu":
            self.activation = jax.nn.relu
        else:
            self.activation = jax.nn.tanh
    
    def __call__(self, x: Array) -> Array:
        x = self.dense1(x)
        x = self.activation(x)
        x = self.dense2(x)
        x = self.activation(x)
        x = self.dense3(x)
        x = self.activation(x)
        x = self.dense4(x)
        return x



class Timestep:
    obs: Array
    action: Array
    reward: Array
    done: Array

# class CustomTrainState(TrainState):
#     target_network_params: Params
#     timesteps: int
#     n_updates: int

def make_train(config):
    pass

def main():
    config = {
        "LR": 2.5e-4,
        "NUM_ENVS": 4,
        "NUM_STEPS": 128,
        "TOTAL_TIMESTEPS": 5e5,
        "UPDATE_EPOCHS": 4,
        "NUM_MINIBATCHES": 4,
        "GAMMA": 0.99,
        "GAE_LAMBDA": 0.95,
        "CLIP_EPS": 0.2,
        "ENT_COEF": 0.01,
        "VF_COEF": 0.5,
        "MAX_GRAD_NORM": 0.5,
        "ACTIVATION": "tanh",
        "ENV_NAME": "CartPole",
        "ENV_RENDER": "CartPoleRender",
        "PARTIAL_OBS": True,
        "ANNEAL_LR": True,
        "DEBUG": True,
    }

    key = jax.random.PRNGKey(1)
    x = jax.random.normal(jax.random.PRNGKey(0), shape=(2, 512))
    env, env_params= popjym.make("CartPole")
    qnet, state = nn.make_with_state(QNetwork)(key, env.action_space(env_params).n)
    print(env.action_space(env_params).n)
    # qnet = QNetwork(key, env.action_space(env_params).n)
    batch_qnet = jax.vmap(qnet, axis_name="batch", in_axes=0, out_axes=0)
    y_pred = batch_qnet(x)
    print(y_pred.shape)

if __name__ == "__main__":
    main()