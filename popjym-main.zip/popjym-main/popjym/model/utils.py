"""Contains losses and various model update functions"""
from typing import Callable

import jax
import equinox as eqx
from tensorflow_probability.substrates import jax as tfp
from jax import lax
import jax.numpy as jnp
import jax.random as jr
from typing import Tuple, Callable, Any
from jax import lax

@eqx.filter_jit
def filter_scan(f: Callable, init, xs, *args, **kwargs):
    """Same as lax.scan, but allows to have eqx.Module in carry"""
    init_dynamic_carry, static_carry = eqx.partition(init, eqx.is_array)

    def to_scan(dynamic_carry, x):
        carry = eqx.combine(dynamic_carry, static_carry)
        new_carry, out = f(carry, x)
        dynamic_new_carry, _ = eqx.partition(new_carry, eqx.is_array)
        return dynamic_new_carry, out

    out_carry, out_ys = lax.scan(to_scan, init_dynamic_carry, xs, *args, **kwargs)
    return eqx.combine(out_carry, static_carry), out_ys


@eqx.filter_jit
def filter_cond(pred, true_f: Callable, false_f: Callable, *args):
    """Same as lax.cond, but allows to return eqx.Module"""
    dynamic_true, static_true = eqx.partition(true_f(*args), eqx.is_array)
    dynamic_false, static_false = eqx.partition(false_f(*args), eqx.is_array)

    static_part = eqx.error_if(
        static_true,
        static_true != static_false,
        "Filtered conditional arguments should have the same static part",
    )

    dynamic_part = lax.cond(pred, lambda *_: dynamic_true, lambda *_: dynamic_false)
    return eqx.combine(dynamic_part, static_part)


def standard_loss(model, x, y, ord=1, kl_weight=None, key=None):
    """Standard distance loss"""
    z, _, y_hat = eqx.filter_vmap(model)(x)
    loss = jnp.linalg.norm((y - y_hat).flatten(), ord=ord)
    return loss, {"loss": loss}


def spherical_loss(model, x, y, ord=1, kl_weight=0.001, *, key):
    """Standard distance loss and KL loss between PowerSpherical and SphericalUniform"""
    (mu, concentration), _, y_hat = eqx.filter_vmap(model)(x, key)
    uniform = tfp.distributions.SphericalUniform(
        dimension=mu.shape[-1], batch_shape=mu.shape[:-1]
    )
    spherical = tfp.distributions.PowerSpherical(
        mean_direction=mu, concentration=concentration, validate_args=True
    )
    kl_term = spherical.kl_divergence(uniform).mean()
    recon_term = jnp.linalg.norm((y - y_hat).flatten(), ord=ord)
    loss = recon_term + kl_weight * kl_term
    return loss, {
        "loss": loss,
        "recon_loss": recon_term,
        "std_of_mu": mu.std(),
        "mean_of_concentration": concentration.mean(),
        "kl_loss": kl_term,
    }


def gaussian_loss(model, x, y, ord=1, kl_weight=0.05, *, key):
    """Standard distance loss and KL loss between Gaussians"""
    (mu, sigma), _, y_hat = eqx.filter_vmap(model)(x, key)
    prior = tfp.distributions.MultivariateNormalDiag(
        loc=jnp.zeros_like(mu), scale_diag=jnp.ones_like(sigma)
    )
    normal = tfp.distributions.MultivariateNormalDiag(
        loc=mu, scale_diag=sigma, validate_args=True
    )
    kl_term = normal.kl_divergence(prior).mean()
    recon_term = jnp.linalg.norm((y - y_hat).flatten(), ord=ord)
    loss = recon_term + kl_weight * kl_term
    return loss, {
        "loss": loss,
        "recon_loss": recon_term,
        "std_of_mu": mu,
        "mean_of_sigma": sigma,
        "kl_loss": kl_term,
    }


def update_model(model, loss_fn, x, y, opt, opt_state, ord=1, kl_weight=0.001, *, key):
    """Given a loss function, update the model parameters"""
    grad, metrics = eqx.filter_grad(loss_fn, has_aux=True)(
        model, x, y, ord, kl_weight, key
    )
    updates, opt_state = opt.update(
        grad, opt_state, params=eqx.filter(model, eqx.is_inexact_array)
    )
    model = eqx.apply_updates(model, updates)
    return model, opt_state, metrics


@eqx.filter_jit
def scan_one_epoch(
    model, loss_fn, xs, ys, opt, opt_state, ord=1, kl_weight=0.001, *, key
):
    """Train one epoch using the scan operator. Only works if datas is an array, otherwise use train_one_epoch"""
    params, static = eqx.partition(model, eqx.is_array)

    def inner(carry, data):
        params, opt_state, key = carry
        x, y = data
        key = jax.random.split(key)[0]
        model = eqx.combine(params, static)
        params, opt_state, metrics = update_model(
            model, loss_fn, x, y, opt, opt_state, ord, kl_weight, key=key
        )
        params, _ = eqx.partition(params, eqx.is_array)
        return (params, opt_state, key), metrics

    # xs is either list[array]
    # or tuple[list[array], list[array]] if actions are included
    # xs could be tuple (xs, a) or just list of xs
    if isinstance(xs, tuple):
        # ((x, a), y)
        datas = ((jnp.stack(xs[0]), jnp.stack(xs[1])), jnp.stack(ys))
    else:
        # (x, y)
        datas = (jnp.stack(xs), jnp.stack(ys))  # Equivalent to zip(xs, ys)
    (params, opt_state, key), epoch_metrics = jax.lax.scan(
        inner, (params, opt_state, key), datas
    )
    model = eqx.combine(params, static)
    return model, opt_state, epoch_metrics


def train_one_epoch(
    model, loss_fn, xs, ys, opt, opt_state, ord=1, kl_weight=0.001, *, key
):
    """Train one epoch using a for loop"""
    epoch_metrics = []
    for x, y in zip(xs, ys):
        key = jax.random.split(key)[0]
        model, opt_state, metrics = eqx.filter_jit(update_model)(
            model, loss_fn, x, y, opt, opt_state, ord, kl_weight, key=key
        )
        epoch_metrics.append(metrics)

    epoch_metrics = jax.tree_map(lambda *args: jnp.stack(args), epoch_metrics)
    return model, opt_state, epoch_metrics

