from popjym.environments import (CartPole,
                                 CountRecallEasy,
                                 CountRecallMedium,
                                 CountRecallHard,
                                 FullyObservableCountRecallEasy,
                                 FullyObservableCountRecallMedium,
                                 FullyObservableCountRecallHard,
                                 BattleShipEasy,
                                 BattleShipMedium,
                                 BattleShipHard,
                                 )

from popjym.visualize import (CartPoleRender, CountRecallRender, BattleShipRender)


def make(env_id: str, **env_kwargs):
    if env_id == "CartPole":
        env = CartPole(**env_kwargs)
    elif env_id == "CountRecallEasy":
        env = CountRecallEasy(**env_kwargs)
    elif env_id == "CountRecallMedium":
        env = CountRecallMedium(**env_kwargs)
    elif env_id == "CountRecallHard":
        env = CountRecallHard(**env_kwargs)
    elif env_id == "FullyObservableCountRecallEasy":
        env = FullyObservableCountRecallEasy(**env_kwargs)
    elif env_id == "FullyObservableCountRecallMedium":
        env = FullyObservableCountRecallMedium(**env_kwargs)
    elif env_id == "FullyObservableCountRecallHard":
        env = FullyObservableCountRecallHard(**env_kwargs)
    elif env_id == "BattleShipEasy":
        env = BattleShipEasy(**env_kwargs)
    elif env_id == "BattleShipMedium":
        env = BattleShipMedium(**env_kwargs)
    elif env_id == "BattleShipHard":
        env = BattleShipHard(**env_kwargs)
    else:
        raise ValueError("Environment ID is not registered")

    return env, env.default_params


def make_render(render_id: str, **render_kwargs):
    if render_id == "CartPoleRender":
        render = CartPoleRender(**render_kwargs)
    elif render_id == "CountRecallRender":
        render = CountRecallRender(**render_kwargs)
    elif render_id == "BattleShipRender":
        render = BattleShipRender(**render_kwargs)
    else:
        raise ValueError("Render ID is not registered")

    return render


REGISTERED_ENVIRONMENTS = [
    "CartPole",
    "CountRecallEasy",
    "CountRecallMedium",
    "CountRecallHard",
    "FullyObservableCountRecallEasy",
    "FullyObservableCountRecallMedium",
    "FullyObservableCountRecallHard",
    "BattleShipEasy",
    "BattleShipMedium",
    "BattleShipHard",
]

REGISTERED_RENDER = [
    "CartPoleRender",
    "CountRecallRender",
    "BattleShipRender",
]
