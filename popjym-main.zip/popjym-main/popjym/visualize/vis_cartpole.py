import functools
import chex
import jax
import jax.numpy as jnp
import matplotlib.pyplot as plt

from jax import lax
from jax.tree_util import register_pytree_node_class
from popjym.environments.cartpole import EnvState
from popjym.visualize.visualizer import Visualizer


# @register_pytree_node_class
class CartPoleRender(Visualizer):
    def __init__(self, sub_canva_size: int = 192, sub_canva_color: chex.Array = jnp.array([0, 0, 0]),
                 canva_size: int = 256, partial_observable: bool = False,
                 canva_color: chex.Array = jnp.array([0, 0, 0])):
        super().__init__()
        self.partial_observable = partial_observable
        self.canva = jnp.zeros((canva_size, canva_size, 3)) + canva_color
        self.sub_canva = jnp.zeros((sub_canva_size, sub_canva_size, 3)) + sub_canva_color

    @functools.partial(jax.jit, static_argnums=(0,))
    def render(self, state: EnvState) -> chex.Array:
        car_velocity = state.x_dot
        angular_velocity = state.theta_dot
        angle = state.theta
        movement = state.movement
        canva = self.canva
        sub_canva = self.sub_canva
        car_color = jnp.array([0, 1, 0])
        bar_color = jnp.array([0, 0, 1])
        arrow_color = jnp.array([1, 0, 0])
        car_length = sub_canva.shape[0] // 3
        car_height = sub_canva.shape[1] // 6
        car_top_left = (car_length + movement, car_length + car_height)
        car_bottom_right = (car_length * 2 + movement, car_length + car_height * 2)
        straight_arrow_top_left = (10, car_length * 2)
        straight_arrow_bottom_right = (car_length, sub_canva.shape[1])
        crooked_arrow_top_left = (car_length * 2, car_length * 2)
        crooked_arrow_bottom_right = (sub_canva.shape[0] - 10, sub_canva.shape[1] - 10)

        def partial_obs(sub_canva):
            sub_canva = self.draw_straight_arrow(straight_arrow_top_left, straight_arrow_bottom_right, arrow_color,
                                                 car_velocity, sub_canva)
            sub_canva = self.draw_crooked_arrow(crooked_arrow_top_left, crooked_arrow_bottom_right, arrow_color,
                                                angular_velocity, sub_canva)
            return sub_canva

        def fully_obs(sub_canva):
            bar_canva = jnp.zeros((car_length, car_length, 3))
            sub_canva = self.draw_rectangle(car_top_left, car_bottom_right, car_color, sub_canva)
            bar_canva = self.draw_bar((0, 0), (car_length, car_length),
                                      angle=angle, thickness=6,
                                      color=bar_color, canva=bar_canva)
            sub_canva = lax.dynamic_update_slice(sub_canva, bar_canva, (car_height, car_top_left[0], 3))
            sub_canva = self.draw_straight_arrow(straight_arrow_top_left, straight_arrow_bottom_right, arrow_color,
                                                 car_velocity, sub_canva)
            sub_canva = self.draw_crooked_arrow(crooked_arrow_top_left, crooked_arrow_bottom_right, arrow_color,
                                                angular_velocity, sub_canva)

            return sub_canva

        score_top_left = (96, 0)
        score_bottom_right = (96 + 25, 25)
        canva = self.draw_number(score_top_left, score_bottom_right, jnp.array([1, 0, 0]), canva, state.score)
        sub_canva = lax.select(state.time == 0,
                               fully_obs(sub_canva),
                               lax.select(self.partial_observable,
                                          partial_obs(sub_canva),
                                          fully_obs(sub_canva))
                               )
        canva = self.draw_sub_canva(sub_canva, canva)
        return canva

    #
    # def tree_flatten(self):
    #     children = (self.partial_observable, self.canva, self.sub_canva)
    #     aux_data = None
    #     return children, aux_data
    #
    # @classmethod
    # def tree_unflatten(cls, aux_data, children):
    #     return cls(*children)