from popjym.visualize.visualizer import Visualizer
from jax import lax
import jax.numpy as jnp
import jax
import chex
import functools


class BattleShipRender(Visualizer):
    def __init__(self, partial_observable: bool = False, sub_canva_size: int = 192, sub_canva_color: chex.Array = jnp.array([0, 0, 0]), canva_size: int = 256, canva_color: chex.Array = jnp.array([1, 1, 1])):
        super().__init__()
        self.canva_size = canva_size
        self.sub_canva_size = sub_canva_size
        self.partial_observable = partial_observable
        self.canva = jnp.zeros((self.canva_size, self.canva_size, 3)) + canva_color
        self.sub_canva = jnp.zeros((self.sub_canva_size + 2, self.sub_canva_size + 2, 3)) + sub_canva_color

    @functools.partial(jax.jit, static_argnums=(0,))
    def render(self, state) -> chex.Array:
        shape = state.board.shape[0]
        grid_size = self.sub_canva_size // shape
        sub_canva = self.sub_canva
        canva = self.canva
        action_x = state.action_x
        action_y = state.action_y
        top_left = (action_y * grid_size, action_x * grid_size)
        bottom_right = ((action_y + 1) * grid_size, (action_x + 1) * grid_size)

        action_color = jnp.array([255, 255, 0])
        sub_canva = self.draw_rectangle(top_left, bottom_right, action_color, sub_canva)

        def partial_obs(state, sub_canva, top_left, bottom_right):
            thickness = 2
            color = 1
            hit_ship = jnp.logical_and(state.board[state.action_x, state.action_y],
                                        state.guesses[state.action_x, state.action_y])
            hit_empty = jnp.logical_and(jnp.logical_not(state.board[state.action_x, state.action_y]),
                                         state.guesses[state.action_x, state.action_y])
            sub_canva = lax.select(hit_ship,
                                self.draw_x(top_left, bottom_right, color, thickness, sub_canva),
                                lax.select(hit_empty,
                                            self.draw_annulus(top_left, bottom_right,thickness, color, sub_canva),
                                            sub_canva),
                                )
            return sub_canva

        def fully_obs(state, sub_canva, grid_size):
            thickness = 2
            color = 1
            hit_ship = jnp.logical_and(state.board, state.guesses)
            hit_empty = jnp.logical_and(jnp.logical_not(state.board), state.guesses)

            def body_fun(i, sub_canva):
                x = i // state.board.shape[1]
                y = i % state.board.shape[1]
                top_left = (y * grid_size, x * grid_size)
                bottom_right = ((y + 1) * grid_size, (x + 1) * grid_size)
                sub_canva = lax.select(hit_ship[x, y],
                                       self.draw_x(top_left, bottom_right, color, thickness, sub_canva),
                                       sub_canva)
                sub_canva = lax.select(hit_empty[x, y],
                                       self.draw_annulus(top_left, bottom_right, thickness, color, sub_canva),
                                       sub_canva)
                return sub_canva

            num_elements = state.board.shape[0] * state.board.shape[1]
            sub_canva = lax.fori_loop(0, num_elements, body_fun, sub_canva)

            return sub_canva

        score_top_left = (96, 0)
        score_bottom_right = (96 + 25, 25)
        canva = self.draw_number(score_top_left, score_bottom_right, jnp.array([1, 0, 0]), canva, state.score)
        grid_color = jnp.array([0, 0, 255])
        grid_thickness = 1
        sub_canva = lax.select(state.timestep == 0,
                               partial_obs(state, sub_canva, top_left, bottom_right),
                               lax.select(self.partial_observable,
                                          partial_obs(state, sub_canva, top_left, bottom_right),
                                          fully_obs(state, sub_canva, grid_size)
                                          )
                               )
        sub_canva = self.draw_grid(grid_size, grid_thickness, grid_color, sub_canva)
        canva = self.draw_sub_canva(sub_canva, canva)
        return canva



