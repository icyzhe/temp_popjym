from typing import Any, Dict, Optional, Tuple, Union

import chex
import jax
import jax.numpy as jnp
from flax import struct
import functools
from gymnax.environments import environment, spaces
from popjym.environments.draw_utils import (draw_rectangle,
                                            draw_number,
                                            draw_sub_canva,
                                            draw_vertical_arrow,
                                            draw_horizontal_arrow
                                            )


@struct.dataclass
class EnvState:
    velocity_x: float
    velocity_y: float
    lander_position: Tuple[int, int]
    score: int
    timestep: int


@struct.dataclass
class EnvParams:
    """
    gravity: Lunar gravity = 1/6 Earth gravity
    lander_mass: set lander mass = 1.0 kg
    force_meg: set pushing force = 1.0 kg meter per-second
    tau: set timestep = 0.1 second
    lander_threshold: set lander collision threshold
    lander_land: set lander success land
    """
    gravity: float = 1.63
    lander_mass: float = 1.0
    force_meg: float = 1.0
    tau: float = 0.1
    lander_velocity_threshold: float = 1.0
    lander_threshold: Tuple[int, int] = (8, 184)
    lander_land: Tuple[int, int] = (64, 128)


class LunarLander(environment.Environment):
    def __init__(self,
                 slope_size,
                 partial_observable: bool = False,
                 sub_canva_size: int = 192,
                 sub_canva_color: chex.Array = jnp.array([0, 0, 0]),
                 canva_size: int = 256,
                 canva_color: chex.Array = jnp.array([0, 0, 0])
                 ):
        super().__init__()
        """
        ## Description
        This environment is a classic rocket trajectory optimization problem.
        According to Pontryagin's maximum principle, it is optimal to fire the
        engine at full throttle or turn it off. This is the reason why this
        environment has discrete actions: engine on or off.

        Fuel is infinite/finite


        ## Action Space
        There are 5 discrete actions available:
        0: up(increase), 1: down(decrease), 2: left, 3: right, 4: fire(confirm)
        - 0: fire main engine
        - 1: do nothing
        - 2: fire left orientation engine
        - 3: fire right orientation engine
        - 4: do nothing

        ## Observation Space
        The observation space is a 256x256x3 image with RGB color channels.

        ## Reward
        After every timestep a reward is granted. The total reward of an episode is the
        sum of the rewards for all the timesteps within that episode.

        For each timestep, the reward:
        - is increased/decreased the closer/further the lander is to the landing pad.
        - is increased/decreased the slower/faster the lander is moving.
        - is decreased the more the lander is tilted (angle not horizontal).
        - is increased by 10 points for each leg that is in contact with the ground.
        - is decreased by 0.03 points each timestep a side engine is firing.
        - is decreased by 0.3 points each timestep the main engine is firing.

        The episode receive an additional reward of -100 or +100 points for crashing or landing safely respectively.

        An episode is considered a solution if it scores at least 200 points.

        ## Starting State
        The lander starts at the top of the viewport with a random initial x and y position.
        
        ## Episode Termination
        The episode finishes if:
        1) the lander crashes (the lander body gets in contact with the moon);
        2) the lander gets outside of the viewport (`x` coordinate is greater than 1);

        ## Level of difficulty
        The difficulty of the environment can be adjusted by changing the landing pad size.

        """
        self.max_episode_length = 100
        self.slope_size = slope_size
        slope_left = (0, sub_canva_size - slope_size, slope_size, 192)
        slope_right = (192 - slope_size, 192, 192, sub_canva_size - slope_size)
        slope_left_k = (slope_left[3] - slope_left[1]) / (slope_left[2] - slope_left[0])
        slope_left_b = slope_left[1] - slope_left_k * slope_left[0]
        self.slope_left = (slope_left_k, slope_left_b)
        slope_right_k = (slope_right[3] - slope_right[1]) / (slope_right[2] - slope_right[0])
        slope_right_b = slope_right[1] - slope_right_k * slope_right[0]
        self.slope_right = (slope_right_k, slope_right_b)
        """
        Parameters used by lunarlander game render
        """
        self.canva_size = canva_size
        self.sub_canva_size = sub_canva_size
        self.partial_observable = partial_observable
        self.canva = jnp.zeros((self.canva_size, self.canva_size, 3)) + canva_color
        self.sub_canva = jnp.zeros((self.sub_canva_size, self.sub_canva_size, 3)) + sub_canva_color

    @property
    def default_params(self) -> EnvParams:
        return EnvParams()

    def reset_env(self, key: chex.PRNGKey, params: EnvParams) -> Tuple[chex.Array, EnvState]:
        x_key, y_key, vx_key, vy_key = jax.random.split(key, 4)
        position_x = jax.random.randint(x_key, shape=(), minval=8, maxval=self.sub_canva_size - 8)
        position_y = jax.random.randint(y_key, shape=(), minval=8, maxval=24)
        state = EnvState(
            lander_position=(position_x, position_y),
            velocity_x=jax.random.uniform(vx_key, minval=0.1, maxval=0.5, shape=()),
            velocity_y=jax.random.uniform(vy_key, minval=-0.5, maxval=0.5, shape=()),
            score=0,
            timestep=0
        )
        obs = self.get_obs(state)
        return obs, state

    def step_env(
            self,
            key: chex.PRNGKey,
            state: EnvState,
            action: int,
            params: EnvParams,
    ) -> Tuple[chex.Array, EnvState, jnp.ndarray, jnp.ndarray, Dict[Any, Any]]:
        velocity_x = jnp.where(action == 2, state.velocity_x - params.force_meg, state.velocity_x)
        velocity_x = jnp.where(action == 3, state.velocity_x + params.force_meg, velocity_x)
        velocity_y = jnp.where(action == 0, state.velocity_y - params.force_meg, state.velocity_y)
        velocity_y = velocity_y + params.gravity
        lander_x = state.lander_position[0]
        lander_y = state.lander_position[1]
        lander_x += (velocity_x * params.tau).astype(int)
        lander_y += (velocity_y * params.tau).astype(int)
        lander_x = jnp.clip(lander_x, params.lander_threshold[0], params.lander_threshold[1])
        lander_y = jnp.clip(lander_y, params.lander_threshold[0], params.lander_threshold[1])
        new_timestep = state.timestep + 1
        # todo: Reward Function:
        # we need to do the judgement of the speed of the Lander when it get touch with the land
        # and compute the reward corresponding with the distance of the lander and land.
        done_land = jnp.where(
            lander_y + 12 >= self.sub_canva_size,
            True,
            False
        )
        reward = jnp.where(
            done_land,
            jnp.where(
                jnp.logical_or(jnp.abs(velocity_x) > params.lander_velocity_threshold,
                               jnp.abs(velocity_y) > params.lander_velocity_threshold),
                -100,
                100
            ),
            -1
        )
        new_state = state.replace(
            velocity_x=velocity_x,
            velocity_y=velocity_y,
            lander_position=(lander_x, lander_y),
            score=state.score,
            timestep=new_timestep,
        )
        done = jnp.logical_or(self.is_terminal(new_state, params), done_land)
        return self.get_obs(new_state), new_state, reward, done, {}

    def is_terminal(self, state: EnvState, params: EnvParams) -> jnp.ndarray:
        bottom_left = (state.lander_position[0] - 8, state.lander_position[1] + 8)
        bottom_right = (state.lander_position[0] + 8, state.lander_position[1] + 8)
        done_slope = jnp.where(
            jnp.logical_or(
                (bottom_left[1] >= (self.slope_left[0] * bottom_left[0] + self.slope_left[1])),
                (bottom_right[1] >= (self.slope_right[0] * bottom_right[0] + self.slope_right[1])),
            ),
            True,
            False
        )
        done = jnp.logical_or(state.timestep >= self.max_episode_length, done_slope)
        return done

    def render(self, state: EnvState) -> chex.Array:
        r"""
        Render the current state of the environment as an RGB image.

        - Args:
            state: The current state of the environment.

        - Returns:
            An RGB image of the current state of the environment.
        """
        def render_slope(sub_canva, color):
            y, x = jnp.ogrid[:sub_canva.shape[0], :sub_canva.shape[1]]
            mask_left = y >= (self.slope_left[0] * x + self.slope_left[1])
            mask_right = y >= (self.slope_right[0] * x + self.slope_right[1])
            mask = jnp.logical_or(mask_left, mask_right)
            colored_sub_canva = jnp.where(mask[:, :, None], color, sub_canva)
            return colored_sub_canva

        canva = self.canva
        sub_canva = self.sub_canva
        init_x = state.lander_position[0]
        init_y = state.lander_position[1]
        lander_top_left = (init_x - 8, init_y - 8)
        lander_bottom_right = (init_x + 8, init_y + 8)
        lander_color = jnp.array([0.5019607843137255, 0.4, 0.9019607843137255])

        white = jnp.array([1, 1, 1])
        yellow = jnp.array([1, 1, 0])
        land_top_left = (self.slope_size, self.sub_canva_size - 4)
        land_bottom_right = (self.sub_canva_size - self.slope_size, self.sub_canva_size)
        sub_canva = draw_rectangle(lander_top_left, lander_bottom_right, lander_color, sub_canva)
        sub_canva = render_slope(sub_canva, white)
        sub_canva = draw_rectangle(land_top_left, land_bottom_right, yellow, sub_canva)
        score_top_left = (96, 0)
        score_bottom_right = (96 + 25, 25)
        canva = draw_number(score_top_left, score_bottom_right, jnp.array([1, 0, 0]), canva, state.score)
        vy_arrow_top_left = (0, 0)
        vy_arrow_bottom_right = (32, 32)
        canva = draw_vertical_arrow(vy_arrow_top_left, vy_arrow_bottom_right, jnp.array([1, 0, 0]), state.velocity_y, canva)
        vx_arrow_top_left = (256 - 32, 0)
        vx_arrow_bottom_right = (256, 32)
        canva = draw_horizontal_arrow(vx_arrow_top_left, vx_arrow_bottom_right, jnp.array([1, 0, 0]), state.velocity_x, canva)
        canva = draw_sub_canva(sub_canva, canva)
        return canva

    def get_obs(self, state, params=None, key=None, ) -> chex.Array:
        return self.render(state)

    def action_space(self, params: Optional[EnvParams] = None) -> spaces.Discrete:
        """Action space of the environment."""
        # TODO: Multi-Discrete?
        return spaces.Discrete(5)

    def observation_space(self, params: EnvParams) -> spaces.Box:
        """Observation space of the environment."""
        return spaces.Box(jnp.zeros((0,)), jnp.ones((1,)), (256, 256, 3), dtype=jnp.float32)


class LunarLanderEasy(LunarLander):
    def __init__(self, **kwargs):
        super().__init__(slope_size=32, **kwargs)


class LunarLanderMedium(LunarLander):
    def __init__(self, **kwargs):
        super().__init__(slope_size=48, **kwargs)


class LunarLanderHard(LunarLander):
    def __init__(self, **kwargs):
        super().__init__(slope_size=64, **kwargs)