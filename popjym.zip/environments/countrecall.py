from typing import Optional, Tuple, Union

import chex
import jax
import jax.numpy as jnp
from flax import struct
from gymnax.environments import environment, spaces
import functools
from jax import lax
from popjym.environments.draw_utils import (draw_rectangle,
                                            draw_heart,
                                            draw_spade,
                                            draw_club,
                                            draw_diamond,
                                            draw_number,
                                            draw_triangle,
                                            draw_sub_canva)


@struct.dataclass
class EnvState:    
    timestep: int
    value_cards: jnp.ndarray
    query_cards: jnp.ndarray
    running_count: jnp.ndarray
    history: jnp.ndarray
    default_action: int
    num_types: int
    score: int
    alreadyMove: int


@struct.dataclass
class EnvParams:
    pass

@jax.jit
def process_action(state: EnvState, action: int) -> Tuple[EnvState, bool]:
    """
    have 5 actions, 0: up(increase), 1: down(decrease), 2: left, 3: right, 4: fire(confirm)
    """
    new_default_action = jnp.where(action == 0, state.default_action + 1,
                            jnp.where(action == 1, state.default_action - 1,
                            state.default_action))
    
    return state.replace(default_action=new_default_action), action == 4


class CountRecall(environment.Environment):
    def __init__(self, num_decks=1, num_types=2, partial_observable: bool = False):
        self.POMDP = partial_observable
        self.decksize = 26
        # self.error_clamp = error_clamp # NOT IMPLEMENTED
        self.num_decks = num_decks 
        self.num_types = num_types
        self.num_cards = self.decksize * self.num_decks
        self.max_num = self.num_cards // self.num_types # number of every type of card 
        self.reward_scale = 1.0 / self.num_cards
        
        self.maxMove = 100

        self.canva_size = 256
        self.canva_color = jnp.array([0.2, 0.2, 0.5])
        self.large_canva = jnp.ones((self.canva_size, self.canva_size, 3))
    
    @property
    def default_params(self) -> EnvParams:
        return EnvParams()

    def step_env(
        self, key: chex.PRNGKey, state: EnvState, action: Union[int, chex.Array], params: EnvParams
    ) -> Tuple[chex.Array, EnvState, float, bool, dict]:
        """Performs stepping of environment."""
        new_state, fire_action = process_action(state, action)

        prev_count = state.running_count[state.query_cards[state.timestep]]
        reward = jnp.where(fire_action, jnp.where(new_state.default_action == prev_count, self.reward_scale, 0.0), 0.0)
        new_score = state.score + lax.cond(reward > 0, lambda _: 1, lambda _: 0, None)
        running_count = jnp.where(fire_action, state.running_count.at[state.value_cards[state.timestep]].add(1), state.running_count)
        history = jnp.where(fire_action, state.history.at[state.timestep].set(state.value_cards[state.timestep]), state.history)

        new_state = new_state.replace(
            timestep=new_state.timestep + fire_action,
            running_count=running_count,
            history=history,
            score=new_score,
            alreadyMove = new_state.alreadyMove + 1,
        )

        obs = self.get_obs(new_state)
        
        terminated = jnp.logical_or(new_state.timestep == self.num_cards, new_state.alreadyMove >= self.maxMove)
        return obs, new_state, reward, terminated, {}

    def reset_env(self, key: chex.PRNGKey, params: EnvParams) -> Tuple[chex.Array, EnvState]:
        """Performs resetting of environment."""
        key, key_value, key_query = jax.random.split(key, 3)
        cards = jnp.arange(self.decksize * self.num_decks) % self.num_types
        value_cards = jax.random.permutation(key_value, cards) # 2 1 3 2 0 3
        query_cards = jax.random.permutation(key_query, cards) # 3 0 2 1 3 2
        running_count = jnp.zeros((self.num_types,))
        history = jnp.zeros(self.num_cards)
        state = EnvState(
            timestep=0,
            value_cards=value_cards,
            query_cards=query_cards,
            running_count=running_count,
            history=history,
            default_action=0,
            num_types = self.num_types,
            score=0,
            alreadyMove=0,
        )
        obs = self.get_obs(state)
        return obs, state

    @functools.partial(jax.jit, static_argnums=(0,))
    def render(self, state) -> chex.Array:
        """
        Renders the game state on a 192x192x3 canvas.
        num_types can be 2 or 4:
        - For num_types=2: [♥, ♠]
        - For num_types=4: [♥, ♠, ♣, ♦]
        """
        large_canva_size = self.canva_size
        large_canva = self.large_canva
        small_canva_size = 192
        light_blue = jnp.array([0.8, 0.8, 0.9])
        small_canva = jnp.ones((small_canva_size, small_canva_size, 3))
        red = jnp.array([1, 0, 0])
        black = jnp.array([0, 0, 0])
        white = jnp.array([1, 1, 1])

        """
        draw value cards and query cards
        """
        value_cards_top_left = (0, 0)
        value_cards_bottom_right = (20, 40)

        value_suit_top_left = (0, 0)
        value_suit_bottom_right = (20, 40)

        query_cards_top_left = (234, 0)
        query_cards_bottom_right = (254, 40)

        query_suit_top_left = (234, 0)
        query_suit_bottom_right = (254, 40)

        large_canva = draw_rectangle(value_cards_top_left, value_cards_bottom_right, white, large_canva)
        large_canva = draw_rectangle(query_cards_top_left, query_cards_bottom_right, white, large_canva)
        large_canva = lax.cond(
            state.value_cards[state.timestep] == 0,
            lambda large_canva: draw_heart(value_suit_top_left, value_suit_bottom_right, red, large_canva),
            lambda large_canva: lax.cond(
                state.value_cards[state.timestep] == 1,
                lambda large_canva: draw_spade(value_suit_top_left,
                                               (value_suit_bottom_right[0], value_suit_bottom_right[1] - 6), black,
                                               large_canva),
                lambda large_canva: lax.cond(
                    state.value_cards[state.timestep] == 2,
                    lambda large_canva: draw_club(value_suit_top_left,
                                                  (value_suit_bottom_right[0], value_suit_bottom_right[1] - 6), black,
                                                  large_canva),
                    lambda large_canva: draw_diamond(value_suit_top_left, value_suit_bottom_right, red, large_canva),
                    large_canva
                ),
                large_canva
            ),
            large_canva
        )
        large_canva = lax.cond(
            state.query_cards[state.timestep] == 0,
            lambda large_canva: draw_heart(query_suit_top_left, query_suit_bottom_right, red, large_canva),
            lambda large_canva: lax.cond(
                state.query_cards[state.timestep] == 1,
                lambda large_canva: draw_spade(query_suit_top_left,
                                               (query_suit_bottom_right[0], query_suit_bottom_right[1] - 6), black,
                                               large_canva),
                lambda large_canva: lax.cond(
                    state.query_cards[state.timestep] == 2,
                    lambda large_canva: draw_club(query_suit_top_left,
                                                  (query_suit_bottom_right[0], query_suit_bottom_right[1] - 6), black,
                                                  large_canva),
                    lambda large_canva: draw_diamond(query_suit_top_left, query_suit_bottom_right, red, large_canva),
                    large_canva
                ),
                large_canva
            ),
            large_canva
        )

        """
        draw history
        """
        small_canva = lax.cond(
            self.POMDP,
            lambda small_canva: small_canva,
            lambda small_canva: lax.fori_loop(0, state.timestep + 1, lambda i, small_canva: lax.cond(
                i < state.timestep,
                lambda small_canva: lax.switch(
                    lax.convert_element_type(state.history[i], int),
                    [
                        lambda small_canva: draw_heart(
                            ((i % 9) * 20, (i // 9) * 20),
                            ((i % 9) * 20 + 12, (i // 9) * 20 + 20),
                            red,
                            small_canva
                        ),
                        lambda small_canva: draw_spade(
                            ((i % 9) * 20, (i // 9) * 20),
                            ((i % 9) * 20 + 12, (i // 9) * 20 + 20),
                            black,
                            small_canva
                        ),
                        lambda small_canva: draw_club(
                            ((i % 9) * 20, (i // 9) * 20),
                            ((i % 9) * 20 + 12, (i // 9) * 20 + 20),
                            black,
                            small_canva
                        ),
                        lambda small_canva: draw_diamond(
                            ((i % 9) * 20, (i // 9) * 20),
                            ((i % 9) * 20 + 12, (i // 9) * 20 + 20),
                            red,
                            small_canva
                        )
                    ],
                    small_canva
                ),
                lambda small_canva: small_canva,
                small_canva
            ), small_canva),
            small_canva
        )

        """
        draw action controller
        30 
        """
        left_triangle_top_left = (large_canva_size // 2 - 65, 228)
        left_triangle_bottom_right = (large_canva_size // 2 - 35, 254)

        action_top_left = (large_canva_size // 2 - 25, 230)
        action_bottom_right = (large_canva_size // 2, 256)

        right_triangle_top_left = (large_canva_size // 2 + 30, 228)
        right_triangle_bottom_right = (large_canva_size // 2 + 60, 254)

        large_canva = draw_triangle(left_triangle_top_left, left_triangle_bottom_right, black, large_canva, 1)
        large_canva = draw_triangle(right_triangle_top_left, right_triangle_bottom_right, black, large_canva, 2)
        large_canva = draw_number(action_top_left, action_bottom_right, black, large_canva, state.default_action)

        """
        draw score
        """
        score_top_left = (large_canva_size // 2 - 10, 0)
        score_bottom_right = (large_canva_size // 2 + 15, 25)
        large_canva = draw_number(score_top_left, score_bottom_right, red, large_canva, state.score)

        """
        draw sub canva in large canva
        """
        large_canva = draw_sub_canva(small_canva, large_canva)
        return large_canva

    def get_obs(self, state: EnvState) -> chex.Array:
        """Returns observation from the state."""
        obs = self.render(state)
        return obs

    def action_space(self, params: Optional[EnvParams] = None) -> spaces.Discrete:
        """Action space of the environment."""
        return spaces.Discrete(5)

    def observation_space(self, params: EnvParams) -> spaces.Box:
        """Observation space of the environment."""
        return spaces.Box(jnp.array(0,), jnp.array(1,), (256, 256, 3), dtype=jnp.float32)


class CountRecallEasy(CountRecall):
    def __init__(self, partial_observable: bool = False):
        super().__init__(num_decks=1, num_types=2, partial_observable=partial_observable)

class CountRecallMedium(CountRecall):
    def __init__(self, partial_observable: bool = False):
        super().__init__(num_decks=2, num_types=2, partial_observable=partial_observable)

class CountRecallHard(CountRecall):
    def __init__(self, partial_observable: bool = False):
        super().__init__(num_decks=3, num_types=4, partial_observable=partial_observable)