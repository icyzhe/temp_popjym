import functools
from typing import Optional, Tuple

import chex
import jax
import jax.numpy as jnp
import numpy as np
from jax import lax
from flax import struct
from gymnax.environments import environment, spaces

from popjym.environments.draw_utils import (draw_rectangle,
                                            draw_number,
                                            draw_grid,
                                            draw_sub_canva)


@struct.dataclass
class EnvState:
    """
    - mine_grid:
    0: no mine and no viewed
    1: mine
    2: viewed

    - neighbor_grid: record the number of the mines in a (3 * 3) grid
    """
    action_x: int
    action_y: int
    timestep: int
    score: int
    mine_grid: jnp.ndarray
    neighbor_grid: jnp.ndarray


@struct.dataclass
class EnvParams:
    pass


class MineSweeper(environment.Environment):
    def __init__(self, dim: int,
                 num_mines: int = 2,
                 partial_observable: bool = False,
                 sub_canva_size: int = 192,
                 sub_canva_color: chex.Array = jnp.array([0, 0, 0]),
                 canva_size: int = 256,
                 canva_color: chex.Array = jnp.array([1, 1, 1])
                 ):
        super().__init__()
        """
        Parameters used in MineSweeper Game
        """
        self.dim = dim
        self.num_mines = num_mines
        self.max_episode_length = self.dim * self.dim * 3
        self.success_reward_scale = 1 / self.max_episode_length
        self.fail_reward_scale = -0.5 - self.success_reward_scale
        self.bad_action_reward_scale = -0.5 / (self.max_episode_length - 2)
        """
        Parameters used in MineSweeper Game Render
        """
        self.canva_size = canva_size
        self.sub_canva_size = sub_canva_size
        self.partial_observable = partial_observable
        self.canva = jnp.zeros((self.canva_size, self.canva_size, 3)) + canva_color
        self.sub_canva = jnp.zeros((self.sub_canva_size + 2, self.sub_canva_size + 2, 3)) + sub_canva_color

    @property
    def default_params(self) -> EnvParams:
        return EnvParams()

    def step_env(
            self,
            key: chex.PRNGKey,
            state: EnvState,
            action: int,
            params: EnvParams
    ) -> Tuple[chex.Array, EnvState, float, bool, dict]:
        def move_up(state):
            action_x = lax.max(state.action_x - 1, 0)
            new_timestep = state.timestep + 1
            new_state = state.replace(action_x=action_x, timestep=new_timestep)
            done = (new_timestep >= self.max_episode_length)
            return self.get_obs(new_state), new_state, 0.0, done, {}

        def move_down(state):
            action_x = lax.min(state.action_x + 1, self.dim - 1)
            new_timestep = state.timestep + 1
            new_state = state.replace(action_x=action_x, timestep=new_timestep)
            done = (new_timestep >= self.max_episode_length)
            return self.get_obs(new_state), new_state, 0.0, done, {}

        def move_left(state):
            action_y = lax.max(state.action_y - 1, 0)
            new_timestep = state.timestep + 1
            new_state = state.replace(action_y=action_y, timestep=new_timestep)
            done = (new_timestep >= self.max_episode_length)
            return self.get_obs(new_state), new_state, 0.0, done, {}

        def move_right(state):
            action_y = lax.min(state.action_y + 1, self.dim - 1)
            new_timestep = state.timestep + 1
            new_state = state.replace(action_y=action_y, timestep=new_timestep)
            done = (new_timestep >= self.max_episode_length)
            return self.get_obs(new_state), new_state, 0.0, done, {}

        def hit(state):
            action_x, action_y = state.action_x, state.action_y
            mine = state.mine_grid[action_x, action_y] == 1
            viewed = state.mine_grid[action_x, action_y] == 2

            new_grid = state.mine_grid.at[action_x, action_y].set(2)

            reward = self.success_reward_scale
            reward = jnp.where(viewed, self.bad_action_reward_scale, reward)
            reward = jnp.where(mine, self.fail_reward_scale, reward)

            score = state.score
            new_score = score + lax.cond(reward > 0, lambda _:1, lambda _: 0, operand=None)
            terminated = state.timestep == self.max_episode_length
            terminated = jnp.where(mine, True, terminated)
            terminated = jnp.logical_or(terminated, jnp.all(new_grid == 2))

            # obs = obs.at[state.neighbor_grid[action_x, action_y]].set(1)
            # if there is 3 mines around, will set obs[3] = 1

            new_state = state.replace(
                score=new_score,
                timestep=state.timestep + 1,
                mine_grid=new_grid,
                neighbor_grid=state.neighbor_grid,
            )
            obs = self.get_obs(new_state)
            return obs, new_state, reward, terminated, {}

        info = lax.cond(action == 0, move_up,
                        lambda state: lax.cond(action == 1, move_down,
                                               lambda state: lax.cond(action == 2, move_left,
                                                                      lambda state: lax.cond(action == 3, move_right,
                                                                                             hit,
                                                                                             state),
                                                                      state),
                                               state),
                        state)

        return info

    def reset_env(
            self,
            key: chex.PRNGKey,
            params: EnvParams
        ) -> Tuple[chex.Array, EnvState]:
        """Performs resetting of environment."""
        # hidden_grid = jnp.zeros((params.dims[0] * params.dims[1],), dtype=jnp.int8)
        hidden_grid = jnp.zeros((self.dim * self.dim,), dtype=jnp.int8)
        mines_flat = jax.random.choice(
            key, hidden_grid.shape[0], shape=(self.num_mines,), replace=False
        )
        hidden_grid = hidden_grid.at[mines_flat].set(1)
        hidden_grid = hidden_grid.reshape((self.dim, self.dim))
        neighbor_grid = jax.scipy.signal.convolve2d(
            hidden_grid, np.ones((3, 3), dtype=jnp.int8), mode="same"
        )
        neighbor_grid = jnp.array(neighbor_grid, dtype=jnp.int8)
        x_key, y_key = jax.random.split(key)
        action_x = jax.random.randint(x_key, (), 0, self.dim - 1)
        action_y = jax.random.randint(y_key, (), 0, self.dim - 1)
        state = EnvState(
            action_x=action_x,
            action_y=action_y,
            timestep=0,
            score=0,
            mine_grid=hidden_grid,
            neighbor_grid=neighbor_grid,
        )
        return self.get_obs(state), state

    def get_obs(self, state: EnvState, params=None, key=None) -> chex.Array:
        obs = self.render(state)
        return obs

    @functools.partial(jax.jit, static_argnums=(0,))
    def render(self, state) -> chex.Array:
        shape = self.dim
        grid_size = self.sub_canva_size // shape
        sub_canva = self.sub_canva
        canva = self.canva
        action_x = state.action_x
        action_y = state.action_y
        top_left = (action_y * grid_size, action_x * grid_size)
        bottom_right = ((action_y + 1) * grid_size, (action_x + 1) * grid_size)

        action_color = jnp.array([1, 1, 0])
        sub_canva = draw_rectangle(top_left, bottom_right, action_color, sub_canva)
        hit_map = jnp.where(state.mine_grid == 2, True, False)

        def partial_obs(state, sub_canva):
            color = jnp.array([0.678, 0.847, 0.902])
            sub_canva = lax.select(hit_map[action_x, action_y],
                                   draw_number(top_left, bottom_right, color, sub_canva, state.neighbor_grid[action_x, action_y]),
                                   sub_canva)
            return sub_canva

        def fully_obs(state, sub_canva, grid_size):
            color = jnp.array([0.678, 0.847, 0.902])

            def body_fun(i, sub_canva):
                x = i // self.dim
                y = i % self.dim
                top_left = (y * grid_size, x * grid_size)
                bottom_right = ((y + 1) * grid_size, (x + 1) * grid_size)
                sub_canva = lax.select(hit_map[x, y],
                                       draw_number(top_left, bottom_right, color, sub_canva, state.neighbor_grid[x, y]),
                                       sub_canva)
                return sub_canva

            num_elements = self.dim * self.dim
            sub_canva = lax.fori_loop(0, num_elements, body_fun, sub_canva)
            return sub_canva

        score_top_left = (96, 0)
        score_bottom_right = (96 + 25, 25)
        canva = draw_number(score_top_left, score_bottom_right, jnp.array([1, 0, 0]), canva, state.score)
        grid_color = jnp.array([0, 0, 1])
        grid_thickness = 1

        sub_canva = lax.select(state.timestep == 0,
                               partial_obs(state, sub_canva),
                               lax.select(self.partial_observable,
                                          partial_obs(state, sub_canva),
                                          fully_obs(state, sub_canva, grid_size),
                                          )
                               )
        sub_canva = draw_grid(grid_size, grid_thickness, grid_color, sub_canva)
        canva = draw_sub_canva(sub_canva, canva)
        return canva

    def action_space(self, params: Optional[EnvParams] = None) -> spaces.Discrete:
        """Action space of the environment."""
        # TODO: Multi-Discrete?
        return spaces.Discrete(5)

    def observation_space(self, params: EnvParams) -> spaces.Box:
        """Observation space of the environment."""
        return spaces.Box(
            jnp.zeros((self.num_mines,)),
            jnp.ones((self.num_mines,)),
            (self.num_mines,),
            dtype=jnp.float32,
        )


class MineSweeperEasy(MineSweeper):
    def __init__(self, **kwargs):
        super().__init__(dim=4, num_mines=2, **kwargs)


class MineSweeperMedium(MineSweeper):
    def __init__(self, **kwargs):
        super().__init__(dim=6, num_mines=6, **kwargs)


class MineSweeperHard(MineSweeper):
    def __init__(self, **kwargs):
        super().__init__(dim=8, num_mines=10, **kwargs)
