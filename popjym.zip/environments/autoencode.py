from typing import Optional, Tuple

import chex
import jax
import jax.numpy as jnp
from flax import struct
from jax import lax
import functools
from gymnax.environments import environment, spaces
from popjym.environments.draw_utils import (draw_rectangle,
                                            draw_heart,
                                            draw_spade,
                                            draw_club,
                                            draw_diamond,
                                            draw_number,
                                            draw_triangle,
                                            draw_circle,
                                            draw_sub_canva)

@struct.dataclass
class EnvState:
    timestep: int
    cards: jnp.ndarray
    score: int
    watchtimestep: int
    default_action: int


@struct.dataclass
class EnvParams:
    pass


@jax.jit
def process_action(state: EnvState, action: int) -> Tuple[EnvState, bool]:
    """
    have 5 actions, 0: up(increase), 1: down(decrease), 2: left, 3: right, 4: fire(confirm)
    """
    new_default_action = jnp.where(action == 2, state.default_action + 1,
                            jnp.where(action == 3, state.default_action - 1,
                            state.default_action))
    
    return state.replace(default_action=new_default_action), action == 4

class AutoEncode(environment.Environment):
    def __init__(self, num_decks=1, partial_observable=False):
        super().__init__()
        self.POMDP = partial_observable
        self.num_suits = 4
        self.decksize = 26
        self.num_decks = num_decks
        self.canva_size = 256
        self.large_canva = jnp.ones((self.canva_size, self.canva_size, 3))
        self.maxMove = 140

    @property
    def default_params(self) -> EnvParams:
        return EnvParams()

    def step_env(
        self, key: chex.PRNGKey, state: EnvState, action: int, params: EnvParams
    ) -> Tuple[chex.Array, EnvState, float, bool, dict]:
        """Performs step of the environment."""
        new_state, fire_action = process_action(state, action)
        num_cards = self.decksize * self.num_decks
        reward = 0
        
        # if state.timestep <= num_cards, fire_action is always True to let state.timestep + 1
        # if state.timestep > num_cards, fire_action is True when action == 4, which allows
        # agent(player) to choose the action and then fire(confirm) the action
        fire_action = jnp.where(state.timestep <= num_cards, True, fire_action)
        
        reward_scale = 1.0 / (num_cards)

        terminated = jnp.logical_or(
            (state.timestep == num_cards * 2),
            (state.timestep-state.watchtimestep >= self.maxMove) # timelimit
            )
        play = state.timestep >= num_cards

        reward = jnp.where(
            fire_action,
            jnp.where(
                jnp.flip(state.cards, axis=0)[state.timestep - num_cards] == new_state.default_action,
                reward_scale,
                0,
            ),
            0,
        )

        reward = jnp.where(
            play,
            reward,
            0,
        )

        new_state = EnvState(
            new_state.timestep + fire_action,
            new_state.cards, 
            new_state.score + lax.cond(reward > 0, lambda _: 1, lambda _: 0, None),
            new_state.watchtimestep + (1 - play),
            new_state.default_action,
            )
        obs = self.get_obs(new_state)

        return obs, new_state, reward, terminated, {}

    def reset_env(self, key: chex.PRNGKey, params: EnvParams) -> Tuple[chex.Array, EnvState]:
        """Performs resetting of environment."""
        cards = jnp.arange(self.decksize * self.num_decks) % self.num_suits
        cards = jax.random.permutation(key, cards)
        state = EnvState(
            timestep=0,
            cards=cards,
            score=0,
            watchtimestep=0,
            default_action=0,
        )
        obs = self.get_obs(state)
        return obs, state

    @functools.partial(jax.jit, static_argnums=(0,))
    def render(self, state: EnvState) -> None:
        """Renders the environment state. This is also observation of the environment."""
        large_canva_size = self.canva_size
        large_canva = self.large_canva
        small_canva_size = 192
        small_canva = jnp.ones((small_canva_size, small_canva_size, 3))
        red = jnp.array([1, 0, 0])
        black = jnp.array([0, 0, 0])
        white = jnp.array([1, 1, 1])

        """
        draw cards
        """
        value_cards_top_left = (0, 0)
        value_cards_bottom_right = (20, 40)

        value_suit_top_left = (0, 0)
        value_suit_bottom_right = (20, 40)

        large_canva = draw_rectangle(value_cards_top_left, value_cards_bottom_right, white, large_canva)
        large_canva = lax.cond(
            state.timestep < self.decksize * self.num_decks,
            lambda large_canva: lax.cond(
                state.cards[state.watchtimestep] == 0,
                lambda large_canva: draw_heart(value_suit_top_left, value_suit_bottom_right, red, large_canva),
                lambda large_canva: lax.cond(
                    state.cards[state.timestep] == 1,
                    lambda large_canva: draw_spade(value_suit_top_left,
                                                (value_suit_bottom_right[0], value_suit_bottom_right[1] - 6), black,
                                                large_canva),
                    lambda large_canva: lax.cond(
                        state.cards[state.timestep] == 2,
                        lambda large_canva: draw_club(value_suit_top_left,
                                                    (value_suit_bottom_right[0], value_suit_bottom_right[1] - 6), black,
                                                    large_canva),
                        lambda large_canva: draw_diamond(value_suit_top_left, value_suit_bottom_right, red, large_canva),
                        large_canva
                    ),
                    large_canva
                ),
                large_canva
            ),
            lambda large_canva: large_canva,
            large_canva
        )

        """
        draw history
        """
        small_canva = lax.cond(
            self.POMDP,
            lambda small_canva: small_canva,
            lambda small_canva: lax.fori_loop(0, state.watchtimestep + 1, lambda i, small_canva: lax.cond(
                i < state.watchtimestep,
                lambda small_canva: lax.switch(
                    lax.convert_element_type(state.cards[i], int),
                    [
                        lambda small_canva: draw_heart(
                            ((i % 9) * 20, (i // 9) * 20),
                            ((i % 9) * 20 + 12, (i // 9) * 20 + 20),
                            red,
                            small_canva
                        ),
                        lambda small_canva: draw_spade(
                            ((i % 9) * 20, (i // 9) * 20),
                            ((i % 9) * 20 + 12, (i // 9) * 20 + 20),
                            black,
                            small_canva
                        ),
                        lambda small_canva: draw_club(
                            ((i % 9) * 20, (i // 9) * 20),
                            ((i % 9) * 20 + 12, (i // 9) * 20 + 20),
                            black,
                            small_canva
                        ),
                        lambda small_canva: draw_diamond(
                            ((i % 9) * 20, (i // 9) * 20),
                            ((i % 9) * 20 + 12, (i // 9) * 20 + 20),
                            red,
                            small_canva
                        )
                    ],
                    small_canva
                ),
                lambda small_canva: small_canva,
                small_canva
            ), 
            small_canva
            ),
            small_canva
        )

        """
        draw action controller
        """
        left_triangle_top_left = (32+20+10+20+10+20+10-30, 32+192)
        left_triangle_bottom_right = (32+20+10+20+10+20+10-10, 32+192+32)

        current_suit_top_left = (122, 32+192)
        current_suit_bottom_right = (122+20, 32+192+30)

        right_triangle_top_left = (32+20+10+20+10+20+10+20+10, 32+192)
        right_triangle_bottom_right = (32+20+10+20+10+20+10+20+10+20, 32+192+32)

        fire_action_top_left = (32+20+10+20+10+20+10+20+20+20+10+20+10, 32+192)
        fire_action_bottom_right = (32+20+10+20+10+20+10+20+20+20+10+20+10+20, 32+192+32)

        large_canva = lax.switch(
            lax.convert_element_type(state.default_action, int),
            [
                lambda large_canva: draw_heart(current_suit_top_left, current_suit_bottom_right, red, large_canva),
                lambda large_canva: draw_spade(current_suit_top_left, current_suit_bottom_right, black, large_canva),
                lambda large_canva: draw_club(current_suit_top_left, current_suit_bottom_right, black, large_canva),
                lambda large_canva: draw_diamond(current_suit_top_left, current_suit_bottom_right, red, large_canva)
            ],
            large_canva
        )
        large_canva = draw_triangle(left_triangle_top_left, left_triangle_bottom_right, black, large_canva, 3)
        large_canva = draw_triangle(right_triangle_top_left, right_triangle_bottom_right, black, large_canva, 0)
        large_canva = draw_circle(fire_action_top_left, fire_action_bottom_right, 15, black, large_canva)

        """
        draw score
        """
        score_top_left = (large_canva_size // 2 - 10, 0)
        score_bottom_right = (large_canva_size // 2 + 15, 25)
        large_canva = draw_number(score_top_left, score_bottom_right, red, large_canva, state.score)

        """
        draw sub canva in large canva
        """
        large_canva = draw_sub_canva(small_canva, large_canva)
        return large_canva

    def get_obs(self, state: EnvState) -> chex.Array:
        """Returns observation from the state."""
        # play = state.timestep >= self.decksize * self.num_decks 
        # play_obs = jnp.zeros((self.num_suits,))
        # watch_obs = play_obs.at[state.cards[state.timestep]].set(1)
        # obs = jnp.where(play, watch_obs, play_obs)
        obs = self.render(state)
        return obs

    def action_space(self, params: Optional[EnvParams] = None) -> spaces.Discrete:
        """Action space of the environment."""
        return spaces.Discrete(self.num_suits)

    def observation_space(self, params: EnvParams) -> spaces.Box:
        """Observation space of the environment."""
        return spaces.Box(jnp.array(0,), jnp.array(1,), (256, 256, 3), dtype=jnp.float32)



class AutoEncodeEasy(AutoEncode):
    def __init__(self, partial_observable=False):
        super().__init__(num_decks=1, partial_observable=partial_observable)


class AutoEncodeMedium(AutoEncode):
    def __init__(self, partial_observable=False):
        super().__init__(num_decks=2, partial_observable=partial_observable)


class AutoEncodeHard(AutoEncode):
    def __init__(self, partial_observable=False):
        super().__init__(num_decks=3, partial_observable=partial_observable)
