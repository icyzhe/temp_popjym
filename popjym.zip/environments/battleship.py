import functools
import time
from typing import Optional, Tuple

import chex
import jax
from jax import lax
from jax import random
import jax.numpy as jnp
import numpy as np
from flax import struct
from gymnax.environments import environment, spaces
from popjym.environments.draw_utils import (draw_rectangle,
                                            draw_x,
                                            draw_annulus,
                                            draw_grid,
                                            draw_number,
                                            draw_sub_canva)


def is_valid_placement(board, row, col, direction, ship_size):
    """Check if a placement is valid without modifying the board."""
    board_shape = board.shape

    # Slice the board
    horizontal_board = jax.lax.dynamic_slice(board, (row, col), (1, ship_size))
    vertical_board = jax.lax.dynamic_slice(board, (row, col), (ship_size, 1))

    # Check validities
    horizontal_validity = jnp.logical_and(
        col + ship_size <= board_shape[1], jnp.all(horizontal_board == 0)
    )

    vertical_validity = jnp.logical_and(
        row + ship_size <= board_shape[0], jnp.all(vertical_board == 0)
    )

    return jnp.where(direction == 0, horizontal_validity, vertical_validity)


vectorized_validity_check = jax.vmap(
    jax.vmap(
        jax.vmap(is_valid_placement, in_axes=(None, 0, None, None, None)),
        in_axes=(None, None, 0, None, None),
    ),
    in_axes=(None, None, None, 0, None),
)  # Why


def place_ship_on_board(board, row, col, direction, ship_size):
    """Place a ship on the board at the given position and direction."""
    # Generate the horizontal and vertical ship placements
    horizontal_ship = jnp.ones((1, ship_size))
    vertical_ship = jnp.ones((ship_size, 1))

    # Create boards with the ship placed in each direction
    horizontal_board = jax.lax.dynamic_update_slice(board, horizontal_ship, (row, col))
    vertical_board = jax.lax.dynamic_update_slice(board, vertical_ship, (row, col))

    # Use `lax.select` to choose the appropriate board based on the direction
    updated_board = jax.lax.select(direction == 0, horizontal_board, vertical_board)

    return updated_board


def place_random_ship_on_board(rng, board, ship_size):
    size = board.shape[0]
    dirs = jnp.array([0, 1])
    rows = jnp.arange(size)
    cols = jnp.arange(size)
    valid_spots = vectorized_validity_check(board, rows, cols, dirs, ship_size)
    total_num_spots = np.prod(valid_spots.shape)
    rand_valid = jax.random.choice(
        rng, jnp.arange(total_num_spots), shape=(1,), p=valid_spots.flatten()
    )[0]
    direction, col, row = (
        rand_valid // (size * size),
        (rand_valid % (size * size)) // size,
        (rand_valid % (size * size)) % size,
    )

    board = place_ship_on_board(board, row, col, direction, ship_size)
    return board


def generate_random_board(rng, board_size, ship_sizes):
    board = jnp.zeros((board_size, board_size))
    for ship_size in ship_sizes:
        rng, _rng = jax.random.split(rng)
        board = place_random_ship_on_board(_rng, board, ship_size)
    return board


@struct.dataclass
class EnvState:
    action_x: int
    action_y: int
    timestep: int
    board: jnp.ndarray
    guesses: jnp.ndarray
    hits: int
    score: int


@struct.dataclass
class EnvParams:
    pass


class BattleShip(environment.Environment):
    def __init__(self, board_size=8,
                 partial_observable: bool = False,
                 sub_canva_size: int = 192,
                 sub_canva_color: chex.Array = jnp.array([0, 0, 0]),
                 canva_size: int = 256,
                 canva_color: chex.Array = jnp.array([1, 1, 1])
                 ):
        super().__init__()
        """
        Parameters used by cartpole game
        """
        self.board_size = board_size
        self.ship_sizes = [2, 3, 3, 4]
        self.max_episode_length = self.board_size * self.board_size * 3
        self.needed_hits = sum(self.ship_sizes)
        self.reward_hit = 1.0 / self.needed_hits
        self.reward_repeated_hit = -1.0 / (self.max_episode_length - self.needed_hits)
        self.reward_miss = 0.0
        """
        Parameters used by cartpole game render
        """
        self.canva_size = canva_size
        self.sub_canva_size = sub_canva_size
        self.partial_observable = partial_observable
        self.canva = jnp.zeros((self.canva_size, self.canva_size, 3)) + canva_color
        self.sub_canva = jnp.zeros((self.sub_canva_size + 2, self.sub_canva_size + 2, 3)) + sub_canva_color

    @property
    def default_params(self) -> EnvParams:
        return EnvParams()

    def step_env(
            self, key: chex.PRNGKey, state: EnvState, action: int, params: EnvParams
    ) -> Tuple[chex.Array, EnvState, float, bool, dict]:
        def move_up(state):
            action_x = lax.max(state.action_x - 1, 0)
            new_timestep = state.timestep + 1
            new_state = state.replace(action_x=action_x, timestep=new_timestep)
            done = (new_timestep >= self.max_episode_length)
            return self.get_obs(new_state), new_state, 0.0, done, {}

        def move_down(state):
            action_x = lax.min(state.action_x + 1, self.board_size - 1)
            new_timestep = state.timestep + 1
            new_state = state.replace(action_x=action_x, timestep=new_timestep)
            done = (new_timestep >= self.max_episode_length)
            return self.get_obs(new_state), new_state, 0.0, done, {}

        def move_left(state):
            action_y = lax.max(state.action_y - 1, 0)
            new_timestep = state.timestep + 1
            new_state = state.replace(action_y=action_y, timestep=new_timestep)
            done = (new_timestep >= self.max_episode_length)
            return self.get_obs(new_state), new_state, 0.0, done, {}

        def move_right(state):
            action_y = lax.min(state.action_y + 1, self.board_size - 1)
            new_timestep = state.timestep + 1
            new_state = state.replace(action_y=action_y, timestep=new_timestep)
            done = (new_timestep >= self.max_episode_length)
            return self.get_obs(new_state), new_state, 0.0, done, {}

        def hit(state):
            action_x, action_y = state.action_x, state.action_y
            is_ship = state.board[action_x, action_y] == 1
            guessed_before = state.guesses[action_x, action_y] == 1
            hit = jnp.logical_and(is_ship, jnp.logical_not(guessed_before))

            new_guesses = state.guesses.at[action_x, action_y].set(1)
            new_timestep = state.timestep + 1
            new_hits = state.hits + hit
            terminated = jnp.logical_or(new_hits >= self.needed_hits, new_timestep >= self.max_episode_length)
            reward = lax.cond(guessed_before,
                              lambda _: self.reward_repeated_hit,
                              lambda _: jnp.where(hit, self.reward_hit, self.reward_miss), operand=None)

            new_score = state.score + lax.cond(reward > 0, lambda _: 1, lambda _: 0, operand=None)
            new_state = state.replace(
                timestep=new_timestep,
                board=state.board,
                guesses=new_guesses,
                hits=new_hits,
                score=new_score,
            )

            obs = self.get_obs(new_state)

            return obs, new_state, reward, terminated, {}

        info = lax.cond(action == 0, move_up,
                        lambda state: lax.cond(action == 1, move_down,
                                               lambda state: lax.cond(action == 2, move_left,
                                                                      lambda state: lax.cond(action == 3, move_right,
                                                                                             hit,
                                                                                             state),
                                                                      state),
                                               state),
                        state)

        return info

    def reset_env(self, key: chex.PRNGKey, params: EnvParams) -> Tuple[chex.Array, EnvState]:
        """Performs resetting of environment."""
        board = generate_random_board(key, self.board_size, self.ship_sizes)
        guesses = jnp.zeros((self.board_size, self.board_size))
        x_key, y_key = jax.random.split(key)
        action_x = random.randint(x_key, (), 0, self.board_size - 1)
        action_y = random.randint(y_key, (), 0, self.board_size - 1)
        state = EnvState(
            action_x=action_x,
            action_y=action_y,
            timestep=0,
            board=board,
            guesses=guesses,
            hits=0,
            score=0,
        )
        obs = self.get_obs(state)
        return obs, state

    def get_obs(self, state, params=None, key=None, ) -> chex.Array:
        return self.render(state)

    @functools.partial(jax.jit, static_argnums=(0,))
    def render(self, state) -> chex.Array:
        """
        render function will use the current env_state to draw the image format observation of the game,
        Input: EnvState
        Output: chex.Array shape=(256, 256, 3)
        """
        shape = state.board.shape[0]
        grid_size = self.sub_canva_size // shape
        sub_canva = self.sub_canva
        canva = self.canva
        action_x = state.action_x
        action_y = state.action_y
        top_left = (action_y * grid_size, action_x * grid_size)
        bottom_right = ((action_y + 1) * grid_size, (action_x + 1) * grid_size)

        action_color = jnp.array([1, 1, 0])
        sub_canva = draw_rectangle(top_left, bottom_right, action_color, sub_canva)

        def partial_obs(state, sub_canva):
            thickness = 2
            color = jnp.array([1, 1, 1])
            hit_ship = jnp.logical_and(state.board[state.action_x, state.action_y],
                                       state.guesses[state.action_x, state.action_y])
            hit_empty = jnp.logical_and(jnp.logical_not(state.board[state.action_x, state.action_y]),
                                        state.guesses[state.action_x, state.action_y])
            sub_canva = lax.select(hit_ship,
                                   draw_x(top_left, bottom_right, color, thickness, sub_canva),
                                   lax.select(hit_empty,
                                              draw_annulus(top_left, bottom_right, thickness, color, sub_canva),
                                              sub_canva),
                                   )
            return sub_canva

        def fully_obs(state, sub_canva, grid_size):
            thickness = 2
            color = jnp.array([1, 1, 1])
            hit_ship = jnp.logical_and(state.board, state.guesses)
            hit_empty = jnp.logical_and(jnp.logical_not(state.board), state.guesses)

            def body_fun(i, sub_canva):
                x = i // state.board.shape[1]
                y = i % state.board.shape[1]
                top_left = (y * grid_size, x * grid_size)
                bottom_right = ((y + 1) * grid_size, (x + 1) * grid_size)
                sub_canva = lax.select(hit_ship[x, y],
                                       draw_x(top_left, bottom_right, color, thickness, sub_canva),
                                       sub_canva)
                sub_canva = lax.select(hit_empty[x, y],
                                       draw_annulus(top_left, bottom_right, thickness, color, sub_canva),
                                       sub_canva)
                return sub_canva

            num_elements = state.board.shape[0] * state.board.shape[1]
            sub_canva = lax.fori_loop(0, num_elements, body_fun, sub_canva)
            return sub_canva

        score_top_left = (96, 0)
        score_bottom_right = (96 + 25, 25)
        canva = draw_number(score_top_left, score_bottom_right, jnp.array([1, 0, 0]), canva, state.score)
        grid_color = jnp.array([0, 0, 1])
        grid_thickness = 1
        sub_canva = lax.select(state.timestep == 0,
                               partial_obs(state, sub_canva),
                               lax.select(self.partial_observable,
                                          partial_obs(state, sub_canva),
                                          fully_obs(state, sub_canva, grid_size)
                                          )
                               )
        sub_canva = draw_grid(grid_size, grid_thickness, grid_color, sub_canva)
        canva = draw_sub_canva(sub_canva, canva)
        return canva

    def action_space(self, params: Optional[EnvParams] = None) -> spaces.Discrete:
        """Action space of the environment."""
        # TODO: Multi-Discrete?
        return spaces.Discrete(5)

    def observation_space(self, params: EnvParams) -> spaces.Box:
        """Observation space of the environment."""
        return spaces.Box(jnp.zeros((0,)), jnp.ones((1,)), (256, 256, 3), dtype=jnp.float32)


class BattleShipEasy(BattleShip):
    def __init__(self, **kwargs):
        super().__init__(board_size=8, **kwargs)


class BattleShipMedium(BattleShip):
    def __init__(self, **kwargs):
        super().__init__(board_size=10, **kwargs)


class BattleShipHard(BattleShip):
    def __init__(self, **kwargs):
        super().__init__(board_size=12, **kwargs)
