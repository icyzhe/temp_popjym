from popjym.environments.cartpole import (
    CartPoleEasy,
    CartPoleMedium,
    CartPoleHard,
    NoisyCartPoleEasy,
    NoisyCartPoleMedium,
    NoisyCartPoleHard
)

from popjym.environments.countrecall import (CountRecallEasy,
                                             CountRecallHard,
                                             CountRecallMedium,
                                             )
from popjym.environments.battleship import (BattleShipEasy,
                                            BattleShipMedium,
                                            BattleShipHard,
                                            )

from popjym.environments.minesweeper import (MineSweeperEasy,
                                             MineSweeperMedium,
                                             MineSweeperHard)

from popjym.environments.autoencode import (AutoEncodeEasy,
                                            AutoEncodeMedium,
                                            AutoEncodeHard,
                                            )

from popjym.environments.lunarlander import (LunarLanderEasy,
                                             LunarLanderMedium,
                                             LunarLanderHard,
                                             )

from popjym.environments.navigator import (NavigatorEasy,
                                           NavigatorMedium,
                                           NavigatorHard,
                                           )
