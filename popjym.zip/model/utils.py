"""Contains losses and various model update functions"""
from typing import Callable

import jax
import equinox as eqx
from tensorflow_probability.substrates import jax as tfp
from jax import lax
import jax.numpy as jnp
from jaxtyping import Array, Float, Int, jaxtyped
from jax import lax

@eqx.filter_jit
def filter_scan(f: Callable, init, xs, *args, **kwargs):
    """Same as lax.scan, but allows to have eqx.Module in carry"""
    init_dynamic_carry, static_carry = eqx.partition(init, eqx.is_array)

    def to_scan(dynamic_carry, x):
        carry = eqx.combine(dynamic_carry, static_carry)
        new_carry, out = f(carry, x)
        dynamic_new_carry, _ = eqx.partition(new_carry, eqx.is_array)
        return dynamic_new_carry, out

    out_carry, out_ys = lax.scan(to_scan, init_dynamic_carry, xs, *args, **kwargs)
    return eqx.combine(out_carry, static_carry), out_ys


@eqx.filter_jit
def filter_cond(pred, true_f: Callable, false_f: Callable, *args):
    """Same as lax.cond, but allows to return eqx.Module"""
    dynamic_true, static_true = eqx.partition(true_f(*args), eqx.is_array)
    dynamic_false, static_false = eqx.partition(false_f(*args), eqx.is_array)

    static_part = eqx.error_if(
        static_true,
        static_true != static_false,
        "Filtered conditional arguments should have the same static part",
    )

    dynamic_part = lax.cond(pred, lambda *_: dynamic_true, lambda *_: dynamic_false)
    return eqx.combine(dynamic_part, static_part)


def standard_loss(model, x, y, ord=1, kl_weight=None, key=None):
    """Standard distance loss"""
    z, _, y_hat = eqx.filter_vmap(model)(x)
    loss = jnp.linalg.norm((y - y_hat).flatten(), ord=ord)
    return loss, {"loss": loss}


def spherical_loss(model, x, y, ord=1, kl_weight=0.001, *, key):
    """Standard distance loss and KL loss between PowerSpherical and SphericalUniform"""
    (mu, concentration), _, y_hat = eqx.filter_vmap(model)(x, key)
    uniform = tfp.distributions.SphericalUniform(
        dimension=mu.shape[-1], batch_shape=mu.shape[:-1]
    )
    spherical = tfp.distributions.PowerSpherical(
        mean_direction=mu, concentration=concentration, validate_args=True
    )
    kl_term = spherical.kl_divergence(uniform).mean()
    recon_term = jnp.linalg.norm((y - y_hat).flatten(), ord=ord)
    loss = recon_term + kl_weight * kl_term
    return loss, {
        "loss": loss,
        "recon_loss": recon_term,
        "std_of_mu": mu.std(),
        "mean_of_concentration": concentration.mean(),
        "kl_loss": kl_term,
    }


def gaussian_loss(model, x, y, ord=1, kl_weight=0.05, *, key):
    """Standard distance loss and KL loss between Gaussians"""
    (mu, sigma), _, y_hat = eqx.filter_vmap(model)(x, key)
    prior = tfp.distributions.MultivariateNormalDiag(
        loc=jnp.zeros_like(mu), scale_diag=jnp.ones_like(sigma)
    )
    normal = tfp.distributions.MultivariateNormalDiag(
        loc=mu, scale_diag=sigma, validate_args=True
    )
    kl_term = normal.kl_divergence(prior).mean()
    recon_term = jnp.linalg.norm((y - y_hat).flatten(), ord=ord)
    loss = recon_term + kl_weight * kl_term
    return loss, {
        "loss": loss,
        "recon_loss": recon_term,
        "std_of_mu": mu,
        "mean_of_sigma": sigma,
        "kl_loss": kl_term,
    }


def update_model(model, loss_fn, x, y, opt, opt_state, ord=1, kl_weight=0.001, *, key):
    """Given a loss function, update the model parameters"""
    grad, metrics = eqx.filter_grad(loss_fn, has_aux=True)(
        model, x, y, ord, kl_weight, key
    )
    updates, opt_state = opt.update(
        grad, opt_state, params=eqx.filter(model, eqx.is_inexact_array)
    )
    model = eqx.apply_updates(model, updates)
    return model, opt_state, metrics


@eqx.filter_jit
def scan_one_epoch(
    model, loss_fn, xs, ys, opt, opt_state, ord=1, kl_weight=0.001, *, key
):
    """Train one epoch using the scan operator. Only works if datas is an array, otherwise use train_one_epoch"""
    params, static = eqx.partition(model, eqx.is_array)

    def inner(carry, data):
        params, opt_state, key = carry
        x, y = data
        key = jax.random.split(key)[0]
        model = eqx.combine(params, static)
        params, opt_state, metrics = update_model(
            model, loss_fn, x, y, opt, opt_state, ord, kl_weight, key=key
        )
        params, _ = eqx.partition(params, eqx.is_array)
        return (params, opt_state, key), metrics

    # xs is either list[array]
    # or tuple[list[array], list[array]] if actions are included
    # xs could be tuple (xs, a) or just list of xs
    if isinstance(xs, tuple):
        # ((x, a), y)
        datas = ((jnp.stack(xs[0]), jnp.stack(xs[1])), jnp.stack(ys))
    else:
        # (x, y)
        datas = (jnp.stack(xs), jnp.stack(ys))  # Equivalent to zip(xs, ys)
    (params, opt_state, key), epoch_metrics = jax.lax.scan(
        inner, (params, opt_state, key), datas
    )
    model = eqx.combine(params, static)
    return model, opt_state, epoch_metrics


def train_one_epoch(
    model, loss_fn, xs, ys, opt, opt_state, ord=1, kl_weight=0.001, *, key
):
    """Train one epoch using a for loop"""
    epoch_metrics = []
    for x, y in zip(xs, ys):
        key = jax.random.split(key)[0]
        model, opt_state, metrics = eqx.filter_jit(update_model)(
            model, loss_fn, x, y, opt, opt_state, ord, kl_weight, key=key
        )
        epoch_metrics.append(metrics)

    epoch_metrics = jax.tree_map(lambda *args: jnp.stack(args), epoch_metrics)
    return model, opt_state, epoch_metrics

def debug_shape(x):
    return jax.tree.map(lambda x: {x.shape: x.dtype}, x)


def leaky_hard_sigmoid(x, alpha=0.01):
    return jnp.maximum(jnp.minimum(1.0 + alpha * x, (x + 1) / 2), alpha * x)


def leaky_hard_tanh(x, alpha=0.01):
    return jnp.maximum(jnp.minimum(1.0 + alpha * x, x), alpha * x)


def transformer_positional_encoding(
    d_model: int, time_index: Int[Array, ""]
) -> jnp.ndarray:
    """
    Generate a positional encoding vector for a given time index.

    Args:
        time_index (int): The time step index to encode.
        d_model (int): The dimensionality of the encoding vector.

    Returns:
        jnp.ndarray: A positional encoding vector of shape (d_model,).
    """
    position = time_index
    div_term = jnp.exp(jnp.arange(0, d_model, 2) * (-jnp.log(10000.0) / d_model))
    pos_encoding = jnp.zeros(d_model)
    pos_encoding = pos_encoding.at[0::2].set(jnp.sin(position * div_term))
    pos_encoding = pos_encoding.at[1::2].set(jnp.cos(position * div_term))
    return pos_encoding


def gram_schmidt(vectors):
  """Implementation of the modified Gram-Schmidt orthonormalization algorithm.

  We assume here that the vectors are linearly independent. Zero vectors will be
  left unchanged, but will also consume an iteration against `num_vectors`.

  From [1]: "MGS is numerically equivalent to Householder QR factorization
  applied to the matrix A augmented with a square matrix of zero elements on
  top."

  Historical note, see [1]: "modified" Gram-Schmidt was derived by Laplace [2],
  for elimination and not as an orthogonalization algorithm. "Classical"
  Gram-Schmidt actually came later [2]. Classical Gram-Schmidt has a sometimes
  catastrophic loss of orthogonality for badly conditioned matrices, which is
  discussed further in [1].

  #### References

  [1] Bjorck, A. (1994). Numerics of gram-schmidt orthogonalization. Linear
      Algebra and Its Applications, 197, 297-316.

  [2] P. S. Laplace, Thiorie Analytique des Probabilites. Premier Supple'ment,
      Mme. Courtier, Paris, 1816.

  [3] E. Schmidt, über die Auflosung linearer Gleichungen mit unendlich vielen
      Unbekannten, Rend. Circ. Mat. Pulermo (1) 25:53-77 (1908).

  Args:
    vectors: A Tensor of shape `[d, n]` of `d`-dim column vectors to
      orthonormalize.

  Returns:
    A Tensor of shape `[d, n]` corresponding to the orthonormalization.
  """
  num_vectors = vectors.shape[-1]
  def body_fn(vecs, i):
    # Slice out the vector w.r.t. which we're orthogonalizing the rest.
    u = jnp.nan_to_num(vecs[:,i]/jnp.linalg.norm(vecs[:,i]))
    # Find weights by dotting the d x 1 against the d x n.
    weights = u@vecs
    # Project out vector `u` from the trailing vectors.
    masked_weights = jnp.where(jnp.arange(num_vectors) > i, weights, 0.)
    vecs = vecs - jnp.outer(u,masked_weights)
    return vecs, None

  vectors, _ = lax.scan(body_fn, vectors, jnp.arange(num_vectors - 1))
  vec_norm = jnp.linalg.norm(vectors, axis=0, keepdims=True)
  return jnp.nan_to_num(vectors/vec_norm)
