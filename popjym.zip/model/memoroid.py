from typing import Callable, Optional, Tuple

import flax.linen as nn
import jax
from jaxtyping import PRNGKeyArray, Shaped

from popjym.model.mtypes import Input, OutputEmbedding, RecurrentState, SingleRecurrentState
from popjym.model.groups import BinaryAlgebra, Module
from popjym.model.scans import magma_scan, monoid_scan


class Memoroid(Module):
    r"""A memoroid from https://arxiv.org/abs/2402.09900

    Given a recurrent state and inputs, returns the corresponding recurrent states and outputs

    A memoroid contains a monoid or magma :math:`(H, \bullet)` and two maps/functions :math:`f,g`

    We use f, g to map to and from the monoid space

    .. math::

        f: X^n \times \{0, 1\}^n \mapsto H^n

        \bullet: H \times H \mapsto H

        g: H^n \times X^n \{0, \1}^n \mapsto Y^n
    """

    algebra: BinaryAlgebra
    scan: Callable[
        [
            Callable[[RecurrentState, RecurrentState], RecurrentState],
            RecurrentState,
            RecurrentState,
        ],
        RecurrentState,
    ]

    def forward_map(
        self, x: Input, key: Optional[Shaped[PRNGKeyArray, ""]] = None
    ) -> RecurrentState:
        """Maps inputs to the monoid space"""
        raise NotImplementedError

    def backward_map(
        self,
        h: RecurrentState,
        x: Input,
        key: Optional[Shaped[PRNGKeyArray, ""]] = None,
    ) -> OutputEmbedding:
        """Maps the monoid space to outputs"""
        raise NotImplementedError

    @nn.compact
    def __call__(
        self,
        h: SingleRecurrentState,
        x: Input,
        key: Optional[Shaped[PRNGKeyArray, ""]] = None,
    ) -> Tuple[RecurrentState, OutputEmbedding]:
        """Calls the mapping and scan functions.

        You probably do not need to override this."""
        if key is None:
            in_key, out_key = (None, None)
        else:
            in_key, out_key = jax.random.split(key)
        scan_input = jax.vmap(self.forward_map)(x, in_key)
        next_h = self.scan(self.algebra, h, scan_input)
        y = jax.vmap(self.backward_map)(next_h, x, out_key)
        return next_h, y

    def initialize_carry(
        self, key: Optional[Shaped[PRNGKeyArray, ""]] = None
    ) -> SingleRecurrentState:
        """Initialize the recurrent state for a new sequence."""
        return self.algebra.initialize_carry(key=key)

    @nn.nowrap
    def zero_carry(self) -> RecurrentState:
        return self.algebra.zero_carry()

    @nn.nowrap
    def latest_recurrent_state(self, h: RecurrentState) -> RecurrentState:
        """Get the latest state from a sequence of recurrent states."""
        if self.scan == magma_scan:
            return jax.tree.map(lambda x: x[-1], h)
        elif self.scan == monoid_scan:
            return jax.tree.map(lambda x: x[-1:], h)
        else:
            raise NotImplementedError

    @staticmethod
    def default_algebra(**kwargs):
        raise NotImplementedError

    @staticmethod
    def default_scan():
        raise NotImplementedError
