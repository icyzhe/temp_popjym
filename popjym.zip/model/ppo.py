import jax
import jax.numpy as jnp
import equinox as eqx
import optax

import time
import dataclasses
import popjym
import equinox.nn as nn
from tensorflow_probability.substrates import jax as tfp
from typing import Sequence, Tuple, NamedTuple, Callable
from jaxtyping import PRNGKeyArray, Array
from popjym.wrappers import LogWrapper
from popjym.model.utils import filter_scan
from popjym.model.resnet import resnet18


class Actor(eqx.Module):
    action_dim: Sequence[int] = 5
    activation: Callable
    actor_encoder: ResNet
    actor_mean1: nn.Linear
    actor_mean2: nn.Linear
    actor_mean3: nn.Linear
    actor_mean4: nn.Linear

    def __init__(self, key: PRNGKeyArray):
        key_array = jax.random.split(key, 5)

        self.activation = jax.nn.tanh
        self.actor_encoder = resnet18(key=key_array[0], make_with_state=False)
        self.actor_mean1 = nn.Linear(in_features=512, out_features=256, use_bias=True, key=key_array[1])
        self.actor_mean2 = nn.Linear(in_features=256, out_features=128, use_bias=True, key=key_array[2])
        self.actor_mean3 = nn.Linear(in_features=128, out_features=64, use_bias=True, key=key_array[3])
        self.actor_mean4 = nn.Linear(in_features=64, out_features=5, use_bias=True, key=key_array[4])

    def __call__(self, x: Array) -> Array:
        x = self.actor_encoder(x)
        actor_mean = self.actor_mean1(x)
        actor_mean = self.activation(actor_mean)
        actor_mean = self.actor_mean2(actor_mean)
        actor_mean = self.activation(actor_mean)
        actor_mean = self.actor_mean3(actor_mean)
        actor_mean = self.activation(actor_mean)
        actor_mean = self.actor_mean4(actor_mean)
        # pi = tfp.distributions.Categorical(logits=actor_mean)
        return actor_mean


class Critic(eqx.Module):
    activation: Callable
    critic_encoder: ResNet
    critic_score1: nn.Linear
    critic_score2: nn.Linear
    critic_score3: nn.Linear
    critic_score4: nn.Linear

    def __init__(self, key: PRNGKeyArray):
        key_array = jax.random.split(key, 5)

        self.activation = jax.nn.tanh
        self.critic_encoder = resnet18(key=key_array[0], make_with_state=False)
        self.critic_score1 = nn.Linear(in_features=512, out_features=256, use_bias=True, key=key_array[1])
        self.critic_score2 = nn.Linear(in_features=256, out_features=128, use_bias=True, key=key_array[2])
        self.critic_score3 = nn.Linear(in_features=128, out_features=64, use_bias=True, key=key_array[3])
        self.critic_score4 = nn.Linear(in_features=64, out_features=1, use_bias=True, key=key_array[4])

    def __call__(self, x: Array) -> Array:

        x = self.critic_encoder(x)
        critic = self.critic_score1(x)
        critic = self.activation(critic)
        critic = self.critic_score2(critic)
        critic = self.activation(critic)
        critic = self.critic_score3(critic)
        critic = self.activation(critic)
        critic = self.critic_score4(critic)
        return jnp.squeeze(critic, axis=-1)


class Agent(eqx.Module):
    actor: Actor
    critic: Critic

    def __init__(self, key: PRNGKeyArray):
        rng, _rng = jax.random.split(key)
        self.actor = Actor(key=rng)
        self.critic = Critic(key=_rng)

    def __call__(self, x: Array) -> Tuple[Array, Array]:
        input = x
        actor_means = self.actor(input)
        value = self.critic(x)
        return actor_means, value


class TrainState(eqx.Module):
    opt_state: optax.OptState
    agent: Agent
    optimizer: optax.adam


class Transition(NamedTuple):
    done: jnp.ndarray
    action: jnp.ndarray
    value: jnp.ndarray
    reward: jnp.ndarray
    log_prob: jnp.ndarray
    obs: jnp.ndarray
    info: jnp.ndarray


def make_train(config):
    config["NUM_UPDATES"] = (
            config["TOTAL_TIMESTEPS"] // config["NUM_STEPS"] // config["NUM_ENVS"]
    )
    config["MINIBATCH_SIZE"] = (
            config["NUM_ENVS"] * config["NUM_STEPS"] // config["NUM_MINIBATCHES"]
    )

    env, env_params = popjym.make(config["ENV_NAME"])
    env_render = popjym.make_render(config["ENV_RENDER"], partial_observable=config["PARTIAL_OBS"])
    env = LogWrapper(env)

    def linear_schedule(count):
        frac = (
                1.0 - (count // (config["NUM_MINIBATCHES"] * config["UPDATE_EPOCHS"])) / config["NUM_UPDATES"]
        )
        return config["LR"] * frac

    def cosine_annealing_schedule(count):
        total_steps = config["NUM_MINIBATCHES"] * config["UPDATE_EPOCHS"] * config["NUM_UPDATES"]
        frac = 0.5 * (1 + jnp.cos(jnp.pi * count / total_steps))
        return config["LR"] * frac

    def train(rng):
        rng, _rng = jax.random.split(rng)

        agent = Agent(key=_rng)

        if config["ANNEAL_LR"]:
            tx = optax.chain(
                optax.clip_by_global_norm(config["MAX_GRAD_NORM"]),
                optax.adam(learning_rate=cosine_annealing_schedule, eps=1e-5),
            )

        else:
            tx = optax.chain(
                optax.clip_by_global_norm(config["MAX_GRAD_NORM"]),
                optax.adam(learning_rate=config["LR"], eps=1e-5),
            )

        key, _key = jax.random.split(rng)
        opt_state = tx.init(eqx.filter(agent, eqx.is_array))
        train_state = TrainState(opt_state=opt_state, optimizer=tx, agent=agent)
        reset_rng = jax.random.split(_key, config["NUM_ENVS"])
        obsv, log_env_state = eqx.filter_vmap(env.reset, in_axes=(0, None))(reset_rng, env_params)
        obsv = eqx.filter_vmap(env_render.render)(log_env_state.env_state)
        obsv = jnp.transpose(obsv, (0, 3, 1, 2))

        def update_step(runner_state, _):
            def step_fn(runner_state, _):
                train_state, log_env_state, last_obs, rng = runner_state

                # Select one action for a step
                rng, _rng = jax.random.split(rng)
                actor_means, value = eqx.filter_vmap(train_state.agent)(last_obs)
                pi = tfp.distributions.Categorical(logits=actor_means)
                action = pi.sample(seed=_rng)
                print(action)
                log_prob = pi.log_prob(action)

                # Step the environment
                rng, _rng = jax.random.split(rng)
                rng_step = jax.random.split(_rng, config["NUM_ENVS"])
                obsv, log_env_state, reward, done, info = eqx.filter_vmap(env.step, in_axes=(0, 0, 0, None))(rng_step,
                                                                                                             log_env_state,
                                                                                                             action,
                                                                                                             env_params)
                obsv = eqx.filter_vmap(env_render.render)(log_env_state.env_state)
                obsv = jnp.transpose(obsv, (0, 3, 1, 2))
                transition = Transition(done, action, value, reward, log_prob, last_obs, info)
                runner_state = (train_state, log_env_state, obsv, rng)
                return runner_state, transition

            runner_state, traj_batch = filter_scan(step_fn, runner_state, None, config["NUM_STEPS"])
            print("finish get batch")

            """
            Calculate advantage
            """
            train_state, log_env_state, last_obs, rng = runner_state
            actor_means, last_val = eqx.filter_vmap(train_state.agent)(last_obs)

            def calculate_gae(traj_batch, last_val):
                def get_advantages(gae_and_next_value, transition):
                    gae, next_value = gae_and_next_value
                    done, value, reward = (
                        transition.done,
                        transition.value,
                        transition.reward,
                    )
                    # delta_t = r_t + gamma * V(s_{t+1}) - V(s_t)
                    delta = reward + config["GAMMA"] * next_value * (1 - done) - value
                    # gae = sum_{l=0}^{\infin} (gamma * lambda)^l * delta_{t + l}
                    gae = (
                            delta + config["GAMMA"] * config["GAE_LAMBDA"] * (1 - done) * gae
                    )
                    return (gae, value), gae

                _, advantages = jax.lax.scan(get_advantages,
                                             (jnp.zeros_like(last_val), last_val),
                                             traj_batch,
                                             reverse=True,
                                             unroll=16)
                return advantages, advantages + traj_batch.value

            advantages, targets = calculate_gae(traj_batch, last_val)

            def update_epoch(update_state, _):

                def update_minibatch(train_state, batch_info):
                    traj_batch, advantages, targets = batch_info

                    def loss_fn(model, traj_batch, gae, targets):
                        actor_means, value = eqx.filter_vmap(model)(traj_batch.obs)
                        pi = tfp.distributions.Categorical(logits=actor_means)
                        log_prob = pi.log_prob(traj_batch.action)

                        # Calculate Critic Loss
                        value_pred_clipped = traj_batch.value + (
                                value - traj_batch.value
                        ).clip(-config["CLIP_EPS"], config["CLIP_EPS"])
                        value_losses = jnp.square(value - targets)
                        value_losses_clipped = jnp.square(value_pred_clipped - targets)
                        value_loss = (
                                0.5 * jnp.maximum(value_losses, value_losses_clipped).mean()
                        )

                        # Calculate Actor Loss
                        # Setting the extent of model updating
                        ratio = jnp.exp(log_prob - traj_batch.log_prob)
                        gae = (gae - gae.mean()) / (gae.std() + 1e-8)
                        loss_actor1 = ratio * gae
                        loss_actor2 = (
                                jnp.clip(
                                    ratio,
                                    1.0 - config["CLIP_EPS"],
                                    1.0 + config["CLIP_EPS"],
                                )
                                * gae
                        )
                        loss_actor = -jnp.minimum(loss_actor1, loss_actor2)
                        loss_actor = loss_actor.mean()
                        entropy = pi.entropy().mean()
                        total_loss = (
                                loss_actor
                                + config["VF_COEF"] * value_loss
                                - config["ENT_COEF"] * entropy
                        )
                        data = {
                            "actor_loss": loss_actor,
                            "value_loss": value_loss,
                            "entropy_loss": entropy,
                        }
                        return total_loss, data


                    (total_loss, _), grads = eqx.filter_value_and_grad(loss_fn, has_aux=True)(
                        train_state.agent, traj_batch, advantages, targets)
                    jax.debug.print("total loss:{}", total_loss)
                    updates, new_opt_state = train_state.optimizer.update(
                        grads,
                        train_state.opt_state,
                        eqx.filter(train_state.agent, eqx.is_array),
                    )
                    print("finish update the minibatch")

                    new_agent = eqx.apply_updates(train_state.agent, updates)
                    new_train_state = dataclasses.replace(train_state,
                                                          opt_state=new_opt_state,
                                                          agent=new_agent)
                    return train_state, total_loss
                train_state, traj_batch, advantages, targets, rng = update_state
                rng, _rng = jax.random.split(rng)

                # Batching and Shuffling
                batch_size = config["MINIBATCH_SIZE"] * config["NUM_MINIBATCHES"]
                assert (
                        batch_size == config["NUM_STEPS"] * config["NUM_ENVS"]
                ), "Batch size must be equal to number of steps * number of envs"
                permutation = jax.random.permutation(_rng, batch_size)
                batch = (traj_batch, advantages, targets)
                batch = jax.tree_util.tree_map(
                    lambda x: x.reshape((batch_size,) + x.shape[2:]), batch
                )
                shuffled_batch = jax.tree_util.tree_map(
                    lambda x: jnp.take(x, permutation, axis=0), batch
                )

                # Doing minibatch update
                mini_batches = jax.tree_util.tree_map(
                    lambda x: jnp.reshape(x, [config["NUM_MINIBATCHES"], -1] + list(x.shape[1:])),
                    shuffled_batch
                )
                train_state, total_loss = filter_scan(update_minibatch, train_state, mini_batches)
                print("finish update epoch")
                update_state = (train_state, traj_batch, advantages, targets, rng)
                return update_state, total_loss

            update_state = (train_state, traj_batch, advantages, targets, rng)
            update_state, loss_info = filter_scan(update_epoch, update_state, None, config["UPDATE_EPOCHS"])
            print("finish update step")
            train_state = update_state[0]
            metric = traj_batch.info
            rng = update_state[-1]

            runner_state = (train_state, log_env_state, last_obs, rng)
            return runner_state, metric

        rng, _rng = jax.random.split(rng)
        runner_state = (train_state, log_env_state, obsv, rng)
        print(config["NUM_UPDATES"])
        runner_state, metric = filter_scan(update_step, runner_state, None, config["NUM_UPDATES"])
        print("finish train")
        train_state, log_env_state, obsv, rng = runner_state
        return {"runner_state": runner_state, "metric": metric}

    return train

from matplotlib import pyplot as plt
def evaluate(model: eqx.Module):
    seed = jax.random.PRNGKey(10)
    env, env_params = popjym.make("CartPole")
    obs, state = env.reset(seed, env_params)
    env_render = popjym.make_render("CartPoleRender", partial_observable=False)
    obs = env_render.render(state)
    plt.axis('off')
    plt.imshow(obs)
    plt.show()
    obs = jnp.transpose(obs, (2, 0, 1))
    for i in range(20):
        rng, rng_act, rng_step, _rng = jax.random.split(seed, 4)
        actor_mean, value = model(obs)
        action = jnp.argmax(actor_mean)
        print(actor_mean)
        obs2, new_state, reward, term, _ = env.step(rng_step, state, action=action)
        state = new_state
        obs = env_render.render(new_state)
        plt.axis('off')
        plt.imshow(obs)
        plt.show()
        obs = jnp.transpose(obs, (2, 0, 1))

if __name__ == "__main__":
    config = {
        "LR": 2.5e-4,
        "NUM_ENVS": 4,
        "NUM_STEPS": 128,
        "TOTAL_TIMESTEPS": 5e5,
        "UPDATE_EPOCHS": 4,
        "NUM_MINIBATCHES": 4,
        "GAMMA": 0.99,
        "GAE_LAMBDA": 0.95,
        "CLIP_EPS": 0.2,
        "ENT_COEF": 0.01,
        "VF_COEF": 0.5,
        "MAX_GRAD_NORM": 0.5,
        "ACTIVATION": "tanh",
        "ENV_NAME": "CartPole",
        "ENV_RENDER": "CartPoleRender",
        "PARTIAL_OBS": False,
        "ANNEAL_LR": True,
        "DEBUG": True,
    }

    rng = jax.random.PRNGKey(30)
    train_fn = eqx.filter_jit(make_train(config))
    before = time.time()
    out = train_fn(rng)
    runner_state = out["runner_state"]
    train_state, log_env_state, obsv, rng = runner_state
    eqx.tree_serialise_leaves('ppo_model.pkl', train_state.agent)
    after = time.time()
    print(after - before)
    rng, _rng = jax.random.split(rng)
    agent = Agent(key=_rng)
    model = eqx.tree_deserialise_leaves('ppo_model.pkl', agent)
    evaluate(model)






