from popjym.environments import (CartPoleEasy,
                                 CartPoleMedium,
                                 CartPoleHard,
                                 NoisyCartPoleEasy,
                                 NoisyCartPoleMedium,
                                 NoisyCartPoleHard,
                                 CountRecallEasy,
                                 CountRecallMedium,
                                 CountRecallHard,
                                 BattleShipEasy,
                                 BattleShipMedium,
                                 BattleShipHard,
                                 MineSweeperEasy,
                                 MineSweeperMedium,
                                 MineSweeperHard,
                                 AutoEncodeEasy,
                                 AutoEncodeMedium,
                                 AutoEncodeHard, 
                                 NoisyCartPoleEasy, 
                                 NoisyCartPoleMedium, 
                                 NoisyCartPoleHard,
                                 LunarLanderEasy,
                                 LunarLanderMedium,
                                 LunarLanderHard,
                                 NavigatorEasy,
                                 NavigatorMedium,
                                 NavigatorHard,
                                 )


def make(env_id: str, **env_kwargs):
    if env_id == "CartPoleEasy":
        env = CartPoleEasy(**env_kwargs)
    elif env_id == "CartPoleMedium":
        env = CartPoleMedium(**env_kwargs)
    elif env_id == "CartPoleHard":
        env = CartPoleHard(**env_kwargs)
    elif env_id == "NoisyCartPoleEasy":
        env = NoisyCartPoleEasy(**env_kwargs)
    elif env_id == "NoisyCartPoleMedium":
        env = NoisyCartPoleMedium(**env_kwargs)
    elif env_id == "NoisyCartPoleHard":
        env = NoisyCartPoleHard(**env_kwargs)
    elif env_id == "CountRecallEasy":
        env = CountRecallEasy(**env_kwargs)
    elif env_id == "CountRecallMedium":
        env = CountRecallMedium(**env_kwargs)
    elif env_id == "CountRecallHard":
        env = CountRecallHard(**env_kwargs)
    elif env_id == "BattleShipEasy":
        env = BattleShipEasy(**env_kwargs)
    elif env_id == "BattleShipMedium":
        env = BattleShipMedium(**env_kwargs)
    elif env_id == "BattleShipHard":
        env = BattleShipHard(**env_kwargs)
    elif env_id == "MineSweeperEasy":
        env = MineSweeperEasy(**env_kwargs)
    elif env_id == "MineSweeperMedium":
        env = MineSweeperMedium(**env_kwargs)
    elif env_id == "MineSweeperHard":
        env = MineSweeperHard(**env_kwargs)
    elif env_id == "AutoEncodeEasy":
        env = AutoEncodeEasy(**env_kwargs)
    elif env_id == "AutoEncodeMedium":
        env = AutoEncodeMedium(**env_kwargs)
    elif env_id == "AutoEncodeHard":
        env = AutoEncodeHard(**env_kwargs)
    elif env_id == "LunarLanderEasy":
        env = LunarLanderEasy(**env_kwargs)
    elif env_id == "LunarLanderMedium":
        env = LunarLanderMedium(**env_kwargs)
    elif env_id == "LunarLanderHard":
        env = LunarLanderHard(**env_kwargs)
    elif env_id == "NavigatorEasy":
        env = NavigatorEasy(**env_kwargs)
    elif env_id == "NavigatorMedium":
        env = NavigatorMedium(**env_kwargs)
    elif env_id == "NavigatorHard":
        env = NavigatorHard(**env_kwargs)
    else:
        raise ValueError("Environment ID is not registered")

    return env, env.default_params


REGISTERED_ENVIRONMENTS = [
    "CartPoleEasy",
    "CartPoleMedium",
    "CartPoleHard",
    "NoisyCartPoleEasy",
    "NoisyCartPoleMedium",
    "NoisyCartPoleHard",
    "CountRecallEasy",
    "CountRecallMedium",
    "CountRecallHard",
    "BattleShipEasy",
    "BattleShipMedium",
    "BattleShipHard",
    "AutoEncodeEasy",
    "AutoEncodeMedium",
    "AutoEncodeHard",
    "LunarLanderEasy",
    "LunarLanderMedium",
    "LunarLanderHard",
    "NavigatorEasy",
    "NavigatorMedium",
    "NavigatorHard",
]
